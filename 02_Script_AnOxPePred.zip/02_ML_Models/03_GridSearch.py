

import optparse, os
import numpy as np
import pandas as pd


parser = optparse.OptionParser()

parser.add_option('-i', dest='INPUT_DIR', default='/home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Results/GridSearch', help='Directory with all input files')
(options,args) = parser.parse_args()

INPUT_DIR = options.INPUT_DIR

data_df = pd.DataFrame(columns=['S_thres','S_MCC','S_AUC','S_AP','C_thres','C_MCC','C_AUC','C_AP'])

for (dirpath, dirnames, filenames) in os.walk(INPUT_DIR):
    for filename in filenames:
        if filename.startswith('CNN'):
            a_path = os.path.normpath(dirpath).split(os.path.sep)
            with open(os.path.join(dirpath,filename), 'r') as f:
                a_data = []
                for line in f:
                    if line.startswith('#'):
                        a_tmp = line.strip('\n').replace('\t\t', '\t').split('\t')

                        if len(a_tmp) >=2:
                            a_data.append(a_tmp[1].split(' ')[1])


                tmp_df = pd.DataFrame(data=np.array([a_data]),columns=['S_thres', 'S_MCC', 'S_AUC', 'S_AP', 'C_thres', 'C_MCC', 'C_AUC', 'C_AP'], index=[a_path[-1]])
                data_df = pd.concat([data_df, tmp_df])


print(data_df.head())
data_df = data_df.sort_values(by=['S_MCC'], ascending=False)
print(data_df[['S_MCC','S_thres']].head())
data_df = data_df.sort_values(by=['C_MCC'], ascending=False)
print(data_df[['C_MCC','C_thres']].head())
data_df = data_df.sort_values(by=['S_AP'], ascending=False)
print(data_df[['S_AP']].head())
data_df = data_df.sort_values(by=['C_AP'], ascending=False)
print(data_df[['C_AP']].head())