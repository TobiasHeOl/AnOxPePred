#!/bin/sh

input_dir="/home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Input_data/02_37"
out_dir="/home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Results"
log_dir=$out_dir/logs

out_path=$out_dir/01_CNN_params_H100_F100_B32_L0.0001
in_path=$input_dir/03_B_Partitioned_data.csv

mkdir -p $out_path
mkdir -p $log_dir


#PBS -W group_list=vaccine -A vaccine
#PBS -N CNN_antioxidants
#PBS -e $out_dir/test.err
#PBS -o $out_dir/test.log
#PBS -l nodes=1:ppn=8
#PBS -l mem=120gb
#PBS -l walltime=10:00:00


module load tools anaconda3/4.4.0      

cd /home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Scripts/2Network/

python 01_Antioxidant_CNN.py -i ${in_path} -o ${out_path}/
