#!/bin/sh

input_dir="/home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Input_data/02_37"
input_file=${input_dir}/03_B_Partitioned_data.csv
out_dir="/home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Results/GridSearch"
log_dir=$out_dir/logs

mkdir -p $log_dir
mkdir -p $out_dir


#PBS -W group_list=vaccine -A vaccine
#PBS -N CNN_antioxidants
#PBS -e $log_dir/all.e
#PBS -o $log_dir/all.log
#PBS -l nodes=1:ppn=8
#PBS -l mem=120gb
#PBS -l walltime=01:00:00

N_HIDDEN=("50" "100" "200")
N_FILTER=("50" "100" "200")
N_BATCH=("32" "64" "86")
LEARNING_RATE=("0.003" "0.001" "0.0003" "0.0001")


for H_index in ${!N_HIDDEN[*]};
do
for F_index in ${!N_FILTER[*]};
do
for B_index in ${!N_BATCH[*]};
do
for L_index in ${!LEARNING_RATE[*]};
do
		out_path="$out_dir/CNN_params_H${N_HIDDEN[$H_index]}_F${N_FILTER[$F_index]}_B${N_BATCH[$B_index]}_L${LEARNING_RATE[$L_index]}"
		mkdir -p ${out_path}

		script=${log_dir}/H${N_HIDDEN[$H_index]}_F${N_FILTER[$F_index]}_B${N_BATCH[$B_index]}_L${LEARNING_RATE[$L_index]}.sh
		echo ${log_dir}/H${N_HIDDEN[$H_index]}_F${N_FILTER[$F_index]}_B${N_BATCH[$B_index]}_L${LEARNING_RATE[$L_index]}.sh

cat <<EOF > $script
#!/bin/bash
#PBS -W group_list=vaccine -A vaccine
#PBS -l nodes=1:ppn=28,mem=100gb,walltime=12:00:00
#PBS -d $out_dir
#PBS -o $log_dir/logs_H${N_HIDDEN[$H_index]}_F${N_FILTER[$F_index]}_B${N_BATCH[$B_index]}_L${LEARNING_RATE[$L_index]}.o
#PBS -e $log_dir/logs_H${N_HIDDEN[$H_index]}_F${N_FILTER[$F_index]}_B${N_BATCH[$B_index]}_L${LEARNING_RATE[$L_index]}.e
#PBS -N H${N_HIDDEN[$H_index]}_F${N_FILTER[$F_index]}_B${N_BATCH[$B_index]}_L${LEARNING_RATE[$L_index]}

module load tools anaconda3/4.4.0      

cd /home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Scripts/2Network/

python 01_Antioxidant_CNN.py -i ${input_file} -o ${out_path}/ --hs ${N_HIDDEN[$H_index]} -f ${N_FILTER[$F_index]} -b ${N_BATCH[$B_index]} -r ${LEARNING_RATE[$L_index]}


sleep 5
  
exit 0   
                      
EOF

qsub $script
sleep 1

done
done
done
done









