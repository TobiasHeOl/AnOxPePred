import warnings
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=FutureWarning)
    import pandas as pd
    import numpy as np
    import optparse, os
    from itertools import chain
    import Functions_Antioxidants as ap
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


parser = optparse.OptionParser()
parser.add_option('--hs', dest='h_size', default=100, help="Size of 1st hidden layer, default = 100")
parser.add_option('-f', dest='N_FILTER', default=100, help='Number of filters used in convolution layers, default = 100')
parser.add_option('-b', dest='b_size', default=32, help="Mini batch size, default = 100")
parser.add_option('-e', dest='n_epochs', default=100, help="Number of training epochs, default = 100")
parser.add_option('-r', dest='learning_rate', default=0.0001, help="Learning rate, default = 0.00001")
parser.add_option('-s', dest='n_seeds', default=1, help="Number of seeds, default = 1")
parser.add_option('-o', dest='out_dir', default='CNN_params/', help="Path to out dir")
parser.add_option('-i', dest='data_file', default='DataSet_antioxidants.csv', help="Data file input")
parser.add_option('-z', dest='zscale', default='Extended_Zscale.txt', help="Zscale file")

(options, args) = parser.parse_args()

N_HID = int(options.h_size)                     # Number of hidden nodes
N_FILTER = int(options.N_FILTER)                # Number of filters
N_EPOCH = int(options.n_epochs)                 # Number of Epochs
N_SEEDS = range(1, (int(options.n_seeds)+1))    # Number of seeds
LEARNING_RATE = float(options.learning_rate)    # Learning rate
N_BATCH = int(options.b_size)                   # Size of mini batches
OUT_DIR = options.out_dir
zscale = options.zscale
data_file = options.data_file

########################################
#####  Data Handling             #######
########################################

# Load the data into a DataFrame
data_df = pd.read_csv(data_file, index_col=0)

# Load DataFrame into nested lists
PAR_VEC = np.array(data_df.loc[:, ['partition']]).tolist()
DATA_LIST = np.array(data_df.loc[:, ['Sequence']]).tolist()
TARGET_Scav = np.array(data_df.loc[:, ['Scavenger']]).tolist()
TARGET_Chel = np.array(data_df.loc[:, ['Chelator']]).tolist()

# Turn nested lists into lists
PAR_VEC = list(chain.from_iterable(PAR_VEC))
DATA_LIST = list(chain.from_iterable(DATA_LIST))
TARGET_Scav = list(chain.from_iterable(TARGET_Scav))
TARGET_Chel = list(chain.from_iterable(TARGET_Chel))

# Define DATA and turn sequence into z-score in array format
A_DATA_LIST = np.array(DATA_LIST[:])
z_dic = ap.zscale_read(zscale)
DATA_X = ap.give_score(A_DATA_LIST, z_dic)

# Define TARGETS
TARGET_y = []
TARGET_y += [[TARGET_Scav[num], TARGET_Chel[num]] for num, val in enumerate(TARGET_Scav)]
TARGET_y = np.array(TARGET_y)


#Test single
#TARGET_y = ap.change_order2(TARGET_y)

# Define in/output
N_FEATURES = DATA_X.shape[2]  # Number of inputs
N_TARGETS = TARGET_y.shape[1]  # Number of outputs

# Save hyperparameters
HYPERPARAMETERS = [N_FEATURES, N_TARGETS, LEARNING_RATE, N_EPOCH, N_BATCH, N_HID, N_FILTER]

#######################################
#####  Training the predictions #######
#######################################

ap.NN_construction(DATA_X, TARGET_y, PAR_VEC, N_SEEDS, HYPERPARAMETERS, OUT_DIR, 'CNN_binary_class', nested=True)

#######################################
#####  Testing the predictions ########
#######################################

ap.NN_tester(DATA_X, TARGET_y, PAR_VEC, A_DATA_LIST, N_SEEDS, HYPERPARAMETERS, OUT_DIR, 'NN_performance', nested=True)

