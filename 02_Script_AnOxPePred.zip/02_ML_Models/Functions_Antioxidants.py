from Bio import pairwise2
import os, time
import numpy as np
import tensorflow as tf
import pandas as pd
from sklearn.metrics import *
import matplotlib.pyplot as plt
import seaborn as sns

config = tf.ConfigProto(intra_op_parallelism_threads=2, inter_op_parallelism_threads=2, allow_soft_placement=True)

########################################
#####  Partitioning              #######
########################################

def zscale_read(zscale):
    with open(zscale, 'r') as f:
        z_dic = {}
        for line in f:
            line=line.split()
            z_dic[line[0]] = [float(line[1]),float(line[2]),float(line[3]),float(line[4]),float(line[5])]
    return(z_dic)
def identity_partition(p_list, n_list):

    all_list = p_list + n_list
    all_sort = sorted(all_list, key=len, reverse=True)
    print(3)

    count=0
    a_list =[]
    b_list =[]
    for num1,val1 in enumerate(all_sort):
        if val1 in a_list:
            count+=1
        else:
            a_list += [val1]
            b_list.append([val1])
            for num2, val2 in enumerate(all_list):
                if val2 in a_list:
                    pass
                else:
                    a = pairwise2.align.globalms(val1[0], val2[0], 1, 0, -1, 0)[0][2]

                    if (a)/len(val2[0]) > 0.6:
                        a_list += [val2]
                        b_list[num1-count]+= [val2]
    print(4)
    par_list = [[], [], [], [], []]
    b_list = sorted(b_list, key=len, reverse=True)
    print(5)
    count = 0
    for num, val in enumerate(b_list):
        par_list[num - count] += val
        if (num + 1) % 5 == 0:
            count += 5
            par_list = par_list[::-1]

    #Counts the number of positives and total number of peptides in each partition
    def counter():
        for i in par_list:
            count=0
            for j in i:
                if j[1]=='1':
                    count+=1
            print(len(i))
            print(count)

    print(6)
    PAR_LIST = []
    DATA_LIST = []
    TARGET_y = []
    for num,val in enumerate(par_list):
        [PAR_LIST.append(num) for j in val]
        [DATA_LIST.append(j[0]) for j in val]
        [TARGET_y.append(j[1]) for j in val]

    return(PAR_LIST, DATA_LIST, TARGET_y)
def give_score(a_array, score_dic):

    for i in a_array:
        tmp_list = []
        for j in i:
            tmp_list += [score_dic[j]]

        yield tmp_list
def seq_budding(a_array, length='max'):

    if length == 'max':
        max_l = len(max(a_array, key=len)) + 1
    else:
        max_l = int(length) + 1

    for num, val in enumerate(a_array):
        if len(val) < max_l:
            num_x = (max_l - len(val))
            # Put X's on both sides of the sequence
            yield ('X' * int(np.ceil(num_x / 2))) + val + ('X' * int(np.floor(num_x / 2)))


########################################
#####          Wrap functions    #######
########################################

def NN_construction(DATA_X, TARGET_y, PAR_VEC, N_SEEDS, HYPERPARAMETERS, OUT_DIR, TYPE, nested=True):

    N_PART = len(set(PAR_VEC))
    PAR_VEC = np.array(PAR_VEC)

    # If nested training or not
    if nested == True:
        V_PART = N_PART
    else:
        V_PART = 1

    # Loop training
    for t in range(N_PART):
        for v in range(V_PART):
            if t != v:
                for s in N_SEEDS:

                    DATA_COMBI = [t, v, s]

                    CNN_binary_class(DATA_X, TARGET_y, PAR_VEC, DATA_COMBI, HYPERPARAMETERS, OUT_DIR)

def NN_tester(DATA_X, TARGET_y, PAR_VEC, A_DATA_LIST, N_SEEDS, HYPERPARAMETERS, OUT_DIR, TYPE, nested=True):

    N_PART = len(set(PAR_VEC))
    PAR_VEC = np.array(PAR_VEC)
    #V_PART = [1 for N_PART in N_PART if nested == True]
    #print(V_PART)
    #nested = 'False'
    #V_PART = [1 for N_PART in N_PART if nested == True]
    #print(V_PART)
    #asd
    # If nested training or not
    if nested == True:
        V_PART = N_PART
    else:
        V_PART = 1

    pred_vec_all = []
    cut_off_cross = []

    # Loop training
    for t in range(N_PART):
        list_pred = []
        cut_tmp = []
        # get test set:
        test_idx = np.where(np.array(PAR_VEC) == t)
        # test_y = TARGET_y[test_idx]

        for v in range(V_PART):
            if t != v:
                for s in N_SEEDS:

                    DATA_COMBI = [t, v, s]

                    a_pred = NN_performance(DATA_X, TARGET_y, PAR_VEC, DATA_COMBI, HYPERPARAMETERS, OUT_DIR)

                    cut_tmp.append(pred_threshold(a_pred, TARGET_y[test_idx], t, v))

                    list_pred += [a_pred]


        # Mean predictions of all models for each test fold:
        list_pred = np.array(list_pred)

        test_pred = np.mean(list_pred, axis=0)

        cut_off_cross.append(np.mean(cut_tmp, axis=0))

        #test_sq = squeeze(test_pred)
        #print(test_sq)
        pred_vec_all += test_pred.tolist()
        #print(pred_vec_all)

    pred_vec_all = np.array(pred_vec_all)

    cut_off_cross = np.mean(cut_off_cross, axis=0)
    print(3)
    print(cut_off_cross)

    # Remove X from sequences
    B_DATA_LIST = np.array([i.replace("X", "") for i in A_DATA_LIST])

    inter_values, diff_len = individual_performance(pred_vec_all, TARGET_y, B_DATA_LIST)
    print(inter_values)
    print(diff_len)
    plot_individual(inter_values, diff_len, OUT_DIR)

    performance_csv(pred_vec_all, TARGET_y, DATA_X, A_DATA_LIST, OUT_DIR, cut_off_cross[1])
    performance_file(pred_vec_all, TARGET_y, DATA_X, A_DATA_LIST, OUT_DIR, cut_off_cross[1])

    #plotfigure(pred_vec_all, y_test_all, OUT_DIR)



    print("Files written")

def NN_performance(DATA_X, TARGET_y, PAR_VEC, DATA_COMBI, HYPERPARAMETERS, OUT_DIR):

    # Load hyperparameters
    N_FEATURES, N_TARGETS, LEARNING_RATE, N_EPOCH, N_BATCH, N_HID, N_FILTER = HYPERPARAMETERS
    t, v, s = DATA_COMBI

    print("# predicting test set " + str(t) + "...")

    # get test set:
    test_idx = np.where(np.array(PAR_VEC) == t)
    test_X = DATA_X[test_idx]
    test_y = TARGET_y[test_idx]
    #test_seq = A_DATA_LIST[test_idx]

    # load hyperparameters:
    hyper_params = np.load(OUT_DIR + "params.t." + str(t) + ".v." + str(v) + ".s." + str(s) + ".npz")[
        'arr_1']
    N_FEATURES = int(hyper_params[0])
    N_HID = int(hyper_params[1])
    N_FILTER = int(hyper_params[2])

    # set up network
    yhat, l_in_data, mode = build_CNN(n_features=N_FEATURES, n_targets=N_TARGETS, n_hid=N_HID, n_filters=N_FILTER)
    targets = tf.placeholder(tf.float32, shape=[None, N_TARGETS])
    predict = tf.nn.softmax(yhat)
    yhat = tf.sigmoid(yhat)

    # start tensorflow session:
    sess = tf.Session(config=config)
    sess.run(tf.global_variables_initializer())

    # load weights (parameters) and insert them in network:
    best_params = np.load(OUT_DIR + "params.t." + str(t) + ".v." + str(v) + ".s." + str(s) + ".npz")[
        'arr_0']
    params = tf.trainable_variables()
    for i in range(0, len(params)):
        sess.run(params[i].assign(best_params[i]))

    a_prediction = sess.run(yhat, feed_dict={l_in_data: test_X, targets: test_y, mode: 'TEST'})

    # close session and reset (important):
    sess.close()
    tf.reset_default_graph()

    return(a_prediction.tolist())

def CNN_binary_class(DATA_X, TARGET_y, PAR_VEC, DATA_COMBI, HYPERPARAMETERS, OUT_DIR):

    # Load hyperparameters
    N_FEATURES, N_TARGETS, LEARNING_RATE, N_EPOCH, N_BATCH, N_HID, N_FILTER = HYPERPARAMETERS
    t, v, s = DATA_COMBI

    # Take out the training and validation input and target
    train_idx, val_idx = np.where((PAR_VEC != v) & (PAR_VEC != t)), np.where((PAR_VEC == v))
    X_train, y_train, X_val, y_val = DATA_X[train_idx], TARGET_y[train_idx], DATA_X[val_idx], TARGET_y[val_idx]

    # Training network
    yhat, l_in_data, mode = build_CNN(n_features=N_FEATURES, n_targets=N_TARGETS, n_hid=N_HID, n_filters=N_FILTER)
    targets = tf.placeholder(tf.float32, shape=[None, N_TARGETS])

    # Calculation of loss/cost
    loss = tf.reduce_sum(tf.nn.sigmoid_cross_entropy_with_logits(labels=targets, logits=yhat))

    ###### Start of batch normalization #######
    #with tf.control_dependencies(extra_update_ops):
    #    train_op = optimizer.minimize(loss=loss, global_step=tf.train.get_global_step())


    update_CNN = tf.train.AdamOptimizer(LEARNING_RATE).minimize(loss)

    sess = tf.Session(config=config)

    # Initialize weigths and bias (try different ones)
    sess.run(tf.global_variables_initializer())

    start_time = time.time()
    print("Training network test: " + str(t) + " with validation: " + str(v) + "...")

    val_lowest = 100
    k = 0

    for epoch in range(N_EPOCH):

        e_start_time = time.time()
        train_err, train_batches, val_err, val_batches = 0, 0, 0, 0

        # shuffle training examples and iterate through minbatches:
        for inp in minibatch_random(X_train, y_train, N_BATCH):
            data, target = inp
            _, tmp = sess.run([update_CNN, loss], feed_dict={l_in_data: data, targets: target, mode: 'TRAIN'})
            train_err += tmp
            train_batches += 1

        # predict validation set:
        for inp in minibatch_random(X_val, y_val, N_BATCH):
            data, target = inp
            tmp = sess.run(loss, feed_dict={l_in_data: data, targets: target, mode: 'VALIDATION'})
            val_err +=tmp
            val_batches += 1

        print("Loss: Epoch = {}, train error = {}, validation error = {}".format(epoch + 1, train_err / train_batches, val_err / val_batches))
        print("time: " + str(round(time.time() - e_start_time, 3)) + " s")

        # Save parameter for early stopping
        param_vec = tf.trainable_variables()
        param_vec = [v.eval(session=sess) for v in param_vec]

        # Early stopping
        val_lowest, param_vec, k, a_stop = early_stop(val_err, val_batches, val_lowest, param_vec, DATA_COMBI, HYPERPARAMETERS, OUT_DIR, k)

        if a_stop == 0:
            break

    # report total time used for training:
    print("# Time for training: " + str(round((time.time() - start_time) / 60, 3)) + " min")
    # close session:
    sess.close()
    tf.reset_default_graph()

########################################
#####          Networks          #######
########################################

def build_CNN(n_features, n_targets, n_hid, n_filters):

    # input:
    l_in_data = tf.placeholder(tf.float32, shape=[None, None, n_features])
    mode = tf.placeholder(tf.string)
    l_in_data_dropout = tf.layers.dropout(inputs=l_in_data, rate=0.15, training='TRAIN' == mode)

    # convolutional layers on peptide:
    l_conv_data_1 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=1, kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False), padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_3 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=3, kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False), padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_5 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=5, kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False), padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_7 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=7, kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False), padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_9 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=9, kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False), padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_11 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=11, kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False), padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_1_dropout = tf.layers.dropout(inputs=l_conv_data_1, rate=0.1, training='TRAIN' == mode)
    l_conv_data_3_dropout = tf.layers.dropout(inputs=l_conv_data_3, rate=0.1, training='TRAIN' == mode)
    l_conv_data_5_dropout = tf.layers.dropout(inputs=l_conv_data_5, rate=0.1, training='TRAIN' == mode)
    l_conv_data_7_dropout = tf.layers.dropout(inputs=l_conv_data_7, rate=0.1, training='TRAIN' == mode)
    l_conv_data_9_dropout = tf.layers.dropout(inputs=l_conv_data_9, rate=0.1, training='TRAIN' == mode)
    l_conv_data_11_dropout = tf.layers.dropout(inputs=l_conv_data_11, rate=0.1, training='TRAIN' == mode)

    # max pooling:
    l_pool_max_1 = tf.reduce_max(l_conv_data_1_dropout, axis=1)
    l_pool_max_3 = tf.reduce_max(l_conv_data_3_dropout, axis=1)
    l_pool_max_5 = tf.reduce_max(l_conv_data_5_dropout, axis=1)
    l_pool_max_7 = tf.reduce_max(l_conv_data_7_dropout, axis=1)
    l_pool_max_9 = tf.reduce_max(l_conv_data_9_dropout, axis=1)
    l_pool_max_11 = tf.reduce_max(l_conv_data_11_dropout, axis=1)

    # concatenate:
    l_conc = tf.concat([l_pool_max_1, l_pool_max_3, l_pool_max_5, l_pool_max_7, l_pool_max_9, l_pool_max_11], axis=1)

    # dense hidden layer:
    l_dense = tf.layers.dense(inputs=l_conc, units=n_hid, activation=tf.nn.sigmoid, kernel_initializer=tf.glorot_normal_initializer())
    dropout = tf.layers.dropout(inputs=l_dense, rate=0.4, training='TRAIN'==mode)

    # output layer: (There shouldn't be used an activation function here, as tf cross entropy functions always have a build in activation function)
    yhat = tf.layers.dense(inputs=dropout, units=n_targets, activation=None, kernel_initializer=tf.glorot_normal_initializer())

    return(yhat,l_in_data, mode)

########################################
#####     Network functions      #######
########################################
# Minibatches
def minibatch_random(DATA_X, TARGET_y, N_BATCH):
    assert DATA_X.shape[0]  == TARGET_y.shape[0]

    # Random shuffle
    indices = np.arange(len(DATA_X))
    np.random.shuffle(indices)

    for start_idx in range(0, len(DATA_X), N_BATCH):
        excerpt = indices[start_idx:start_idx + N_BATCH]
        yield DATA_X[excerpt],TARGET_y[excerpt]
def minibatch_ratio(DATA_X, TARGET_y, N_BATCH, ratio):

    # Minibatch with focus on the postives
    assert DATA_X.shape[0] == TARGET_y.shape[0]

    # Take out positives and negatives (this is hardcoded)
    p_indices = [i for i, e in enumerate(TARGET_y.tolist()) if 1 == e[0]]
    n_indices = [i for i, e in enumerate(TARGET_y.tolist()) if 0 == e[0]]

    # Shuffle the positives
    np.random.shuffle(p_indices)
    np.random.shuffle(n_indices)

    p_num = int(np.floor(int(N_BATCH)/int(ratio)))
    n_num = int(N_BATCH - np.floor(int(N_BATCH) / int(ratio)))
    n_start_idx = 0

    for start_idx in range(0, len(p_indices), p_num):

        p_excerpt = p_indices[start_idx:start_idx + p_num]

        n_excerpt = n_indices[n_start_idx:n_start_idx + n_num]

        n_start_idx += n_num

        if len(n_excerpt) < n_num:
            np.random.shuffle(n_indices)

            # Fill in the minibatch of negatives to the correct length
            miss_len = n_num - len(n_excerpt)
            n_start_idx = 0
            n_excerpt += n_indices[n_start_idx:n_start_idx + miss_len]

            # Reset the negatives for the rest of the positives
            n_start_idx = miss_len


        excerpt = p_excerpt + n_excerpt
        yield DATA_X[excerpt],TARGET_y[excerpt]
# Early stopping
def early_stop(val_err, val_batches,val_lowest, param_vec, DATA_COMBI, HYPERPARAMETERS, OUT_DIR, k=0):
    t, v, s = DATA_COMBI
    N_FEATURES, N_TARGETS, LEARNING_RATE, N_EPOCH, N_BATCH, N_HID, N_FILTER = HYPERPARAMETERS
    # Early stopping (if val_er isn't improved 10 times in a row then it stops and the best val_er is used)
    if (val_err / val_batches) < val_lowest:
        val_lowest = (val_err / val_batches)
        param_vec = param_vec[(-1 * len(param_vec)):]

        k = 0
        return(val_lowest,param_vec,k,1)
    elif k <= 10:
        k += 1
        return(val_lowest, param_vec, k,1)
    else:
        np.savez(OUT_DIR + "params.t." + str(t) + ".v." + str(v) + ".s." + str(s) + ".npz", param_vec,
                 np.array([int(N_FEATURES), int(N_HID), int(N_FILTER)]))
        return val_lowest, param_vec, k, 0

########################################
#####          Outputs           #######
########################################

def performance_file(y_pred, TARGET_y, DATA_X, A_DATA_LIST, OUT_DIR, threshold):

    y_pred = change_order(y_pred)
    y_true = change_order(TARGET_y)

    print(y_pred)
    print(y_true)
    average_precision = calc_av_precision(y_pred, y_true)
    mcc, opt_thres = calc_mcc(y_pred, y_true)
    print(mcc)
    print(average_precision)
    #prc, best_t = p_r_curve(y_true[0], y_pred[0], 'Scav', 'b', 'c')
    #prc1, best_t1 = p_r_curve(y_true[1], y_pred[1], 'Che', 'b', 'c')
    #print(prc)
    #print(prc1)
    #best_tres = [best_t, best_t1]

    roc_auc = calc_auc(y_pred, y_true)
    #R_val, P_val = calc_precision_recall(PRED_y, TRUE_y, best_tres)

    # prepare output file:
    outfile = open(OUT_DIR + "CNN_predictions.txt", "w")
    outfile.write("Scav\tChel\tScavPred\tChelPred\tSequence\n")

    for i in range(0, DATA_X.shape[0]):
        outfile.write(str(int(TARGET_y[i][0])) + "\t" + str(int(TARGET_y[i][1])) + "\t" + str(
            y_pred[0][i])[0:7] + "\t\t" + str(y_pred[1][i])[0:7] + "\t\t" + str(A_DATA_LIST[i].replace("X", "")) + "\n")

    names = ['Scavenger','Chelator']
    for num,val in enumerate(roc_auc):

        outfile.write("# "+names[num]+"\n")
        outfile.write("# Threshold\t: "+ str(opt_thres[num]) + "\n")
        #outfile.write("# Recall\t: " + str(R_val[num]) + "\n")
        #outfile.write("# Precision\t: " + str(P_val[num]) + "\n")
        outfile.write("# MCC\t: " + str(mcc[num]) + "\n")
        outfile.write("# AUC\t\t: " + str(roc_auc[num]) + "\n")
        outfile.write("# AP\t\t: " + str(average_precision[num]) + "\n")


    outfile.close()


def performance_csv(y_pred, TARGET_y, DATA_X, A_DATA_LIST, OUT_DIR, threshold):

    #y_pred = change_order(y_pred)
    #y_true = change_order(TARGET_y)

    a_df = pd.DataFrame(data=np.array(list(zip(y_pred, TARGET_y))), columns=[['Scav_pred', 'Chel_pred', 'Scav_true', 'Chel_true']])

    print(a_df)
    asd

    print(y_pred)
    print(y_true)
    average_precision = calc_av_precision(y_pred, y_true)
    mcc, opt_thres = calc_mcc(y_pred, y_true)
    print(mcc)
    print(average_precision)

    roc_auc = calc_auc(y_pred, y_true)
    #R_val, P_val = calc_precision_recall(PRED_y, TRUE_y, best_tres)

    # prepare output file:
    outfile = open(OUT_DIR + "CNN_predictions.txt", "w")
    outfile.write("Scav\tChel\tScavPred\tChelPred\tSequence\n")

    for i in range(0, DATA_X.shape[0]):
        outfile.write(str(int(TARGET_y[i][0])) + "\t" + str(int(TARGET_y[i][1])) + "\t" + str(
            y_pred[0][i])[0:7] + "\t\t" + str(y_pred[1][i])[0:7] + "\t\t" + str(A_DATA_LIST[i].replace("X", "")) + "\n")

    names = ['Scavenger','Chelator']
    for num,val in enumerate(roc_auc):
        pass



def individual_performance(PRED_y, TARGET_y, A_DATA_LIST):

    # Make df with Pred, Target
    PRED_DATA = np.array([[PRED_y[num], TARGET_y[num], A_DATA_LIST[num]] for num, val in enumerate(A_DATA_LIST)])

    a_df = pd.DataFrame(PRED_DATA, columns=['Pred', 'Target', 'Sequence'])
    a_df['Length'] = a_df['Sequence'].apply(len)

    #diff_len = [2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    diff_len = list(range(2,21))

    AP = []
    ROC = []
    mcc = []

    Nr_len = []

    for i in diff_len:
        print(i)
        # Take out only a certain length
        b_df = a_df[a_df['Length'] == i]
        PRED_y = b_df['Pred'].values
        TARGET_y = b_df['Target'].values

        Nr_len.append(len(b_df.index))

        if not list(PRED_y):
            continue

        # Otherwise the array is not 100% an array
        PRED_y = [i for i in PRED_y]
        TARGET_y = [i for i in TARGET_y]

        # Based on when precision and recall is equal
        best_tres = pred_threshold(PRED_y, TARGET_y, 'b', 'c')

        # Change order for the subsequent functions
        PRED_y = change_order(PRED_y)
        TRUE_y = change_order(TARGET_y)

        ROC.append(calc_auc(PRED_y, TRUE_y))
        R_val, P_val = calc_precision_recall(PRED_y, TRUE_y, best_tres)
        AP.append(calc_av_precision(PRED_y, TRUE_y))

        fpr, tpr, threshold1 = roc_curve(TRUE_y[0], PRED_y[0])
        fpr, tpr, threshold2 = roc_curve(TRUE_y[0], PRED_y[0])

        
        mcc_tmp = []
        for num, val in enumerate(threshold1):
            tmp = np.array(np.where(PRED_y[0] >= val, 1, 0))
            mcc_tmp.append([matthews_corrcoef(TRUE_y[0], tmp, sample_weight=None),val])
        
        mcc1 = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)

        mcc_tmp = []
        for num, val in enumerate(threshold2):
            tmp = np.array(np.where(PRED_y[1] >= val, 1, 0))
            mcc_tmp.append([matthews_corrcoef(TRUE_y[1], tmp, sample_weight=None),val])
        
        mcc2 = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)
        mcc.append(np.array([mcc1[0][0],mcc2[0][0]]))


    return(mcc, diff_len)

def predictor(DATA_X, PARAM_dir):
    all_pred = []
    for path in os.listdir(PARAM_dir):
        if path.startswith('params'):

            # set up network:
            hyper_params = np.load(os.path.join(PARAM_dir, path))['arr_1']
            N_FEATURES = int(hyper_params[0])
            N_HID = int(hyper_params[1])
            N_FILTERS = int(hyper_params[2])
            N_TARGETS = 2

            yhat, l_in_data, mode = build_CNN(n_features=N_FEATURES, n_targets=N_TARGETS, n_hid=N_HID, n_filters=N_FILTERS)

            yhat = tf.sigmoid(yhat)

            # start tf session:
            sess = tf.Session(config=config)
            sess.run(tf.global_variables_initializer())

            # set parameters:
            best_params = np.load(os.path.join(PARAM_dir, path))['arr_0']
            params = tf.trainable_variables()
            for i in range(0, len(params)):
                sess.run(params[i].assign(best_params[i]))

            all_pred.append(sess.run(yhat, feed_dict={l_in_data: DATA_X, mode: 'TEST'}))

            # close session:
            sess.close()
            tf.reset_default_graph()

    return (all_pred)


########################################
##### Performance functions      #######
########################################
def calc_auc(PRED_y, TARGET_y):
    roc_auc = []

    for i in range(TARGET_y.shape[0]):
        fpr, tpr, _ = roc_curve(np.array(TARGET_y[i]), np.array(PRED_y[i]))
        roc_auc.append(auc(fpr, tpr))

    return (roc_auc)
def calc_precision_recall(PRED_y, TARGET_y, THRESHOLD):

    R_val, P_val = [], []
    for i in range(TARGET_y.shape[0]):
        BINARY_y = np.where(PRED_y[i] >= THRESHOLD[i], 1, 0)
        tn, fp, fn, tp = confusion_matrix(np.array(TARGET_y[i]), np.array(BINARY_y)).ravel()

        R_val.append(calc_pr_eq(tp, fn))
        P_val.append(calc_pr_eq(tp, fp))

    return (R_val, P_val)
def calc_pr_eq(tp,val):
    # Purpose is to circumventing dividing with 0, but remember it is not mathematically correct
    # if val is fn then it calculates recall, if val is fp it calculates precision
    if tp + val == 0:
        return(0)
    else:
        return(tp / (tp + val))
def calc_av_precision(PRED_y, TARGET_y):
    av_pre = []

    for i in range(TARGET_y.shape[0]):
        average_precision = average_precision_score(TARGET_y[i], PRED_y[i])
        av_pre.append(average_precision)

    return(av_pre)
def calc_mcc(PRED_y, TARGET_y):

    # Based on when precision and recall is equal
    #best_tres = pred_threshold(PRED_y, TARGET_y, 'b', 'c')

    TRUE_y = TARGET_y

    fpr, tpr, threshold = roc_curve(TRUE_y[0], PRED_y[0])


    mcc_tmp = []
    for num, val in enumerate(threshold):
        tmp = np.array(np.where(PRED_y[0] >= val, 1, 0))
        mcc_tmp.append([matthews_corrcoef(TRUE_y[0], tmp, sample_weight=None), val])

    mcc1 = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)

    mcc_tmp = []
    for num, val in enumerate(threshold):
        tmp = np.array(np.where(PRED_y[1] >= val, 1, 0))
        mcc_tmp.append([matthews_corrcoef(TRUE_y[1], tmp, sample_weight=None), val])

    mcc2 = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)
    mcc = np.array([mcc1[0][0], mcc2[0][0]])
    opt_thres = np.array([mcc1[0][1], mcc2[0][1]])

    return(mcc, opt_thres)

########################################
#####       Small functions      #######
########################################

def convert_fsa_list(fasta_file):

    with open(fasta_file, 'r') as a_f:
        for line in a_f:
            if line.startswith('>'):
                yield [line[1:].strip()]
            else:
                yield [line.strip()]
def protein_chop(name_array, seq_array, pep_length):
    for seq_num, seq in enumerate(seq_array):
        for res_num, res in enumerate(seq):
            if res_num + pep_length <= len(seq):
                yield [name_array[seq_num], seq[res_num:(res_num + pep_length)]]
def seq_chop(seq, pep_len=10):
    for res_num, res in enumerate(seq):
        if res_num + pep_len <= len(seq):
            yield seq[res_num:(res_num + pep_len)]
def outer_seq_chop(name_list, seq_list, pep_len=10):
    for name_seq in zip(name_list, seq_list):
        chopped = np.stack(seq_chop(name_seq[1], pep_len))
        yield from zip([name_seq[0]]*len(chopped), chopped)

def switch_dictionary(a_array):

    a_df = pd.DataFrame(data=a_array, columns=['AC', 'Sequence'])

    a_df = a_df.groupby(['Sequence'])['AC'].apply('-'.join).reset_index()

    return [ACs.split('-') for ACs in a_df['AC'].values], a_df['Sequence'].values
def del_redundant(a_list):
    new_list = []
    for i in a_list:
        if i not in new_list:
            new_list += [i]

    return new_list
def calc_ident(seq1, seq2, min_len=False):

    ident = pairwise2.align.globalms(seq1, seq2, 1, 0, -1, -1, penalize_end_gaps=False, score_only=True)

    if min_len == True:
        min_len = min([len(seq1), len(seq2)])
        ident = ident / min_len

    return ident
def homology_partition(a_LIST, ident=0.7, key=None):

    sort_LIST = sorted(a_LIST, key=lambda x: len(x[key]), reverse=True)

    a_df = pd.DataFrame(data=sort_LIST)

    while a_df.shape[0] >= 1:

        tmp_df = a_df.iloc[[0]]
        a_df.drop(a_df.index[[0]], inplace=True)
        b_df = a_df.loc[a_df[key].apply(lambda x: calc_ident(x, tmp_df[key].values[0], min_len=True)) >= ident]
        a_df = a_df.drop(b_df.index).reset_index(drop=True)

        yield pd.concat([tmp_df, b_df]).values
def homology_partition_quick(a_LIST, ident=0.7, key=None):
    # Sort so longest peptides are first and make it into a DataFrame
    a_df = pd.DataFrame(data=sorted(a_LIST, key=lambda x: len(x[key]), reverse=True))


    def inner_homology(tmp_df, a_df, ident, key, loops=1):
        for loop in range(loops):
            # Take out every peptide with specified identity to the first peptide in the cluster
            b_df = a_df.loc[a_df[key].apply(lambda x: calc_ident(x, tmp_df[key].values[0], min_len=True)) >= ident]
            a_df = a_df.drop(b_df.index).reset_index(drop=True)
            yield b_df

    # Loop until all peptides in start DataFrame has been put into a cluster
    while a_df.shape[0] >= 1:
        # Remove the first peptide in the DataFrame
        tmp_df, a_df = a_df.iloc[[0]], a_df.iloc[1:, :]

        b_df = inner_homology(tmp_df, a_df, ident, key, loops=1)
        a_df = a_df.drop(b_df.index).reset_index(drop=True)
        # Yield the cluster and continue
        yield pd.concat([tmp_df, b_df]).values
########################################
#####        Plot functions      #######
########################################
def plot_individual(AP, diff_len, OUT_DIR):

    # Change order for the subsequent functions
    AP = change_order(AP)
    print(AP)
    a_list = [[val, diff_len[num], 'Scav'] for num, val in enumerate(AP[0])]
    b_list = [[val, diff_len[num], 'Chal'] for num, val in enumerate(AP[1])]
    c_list = a_list + b_list
    print(c_list)
    a_df = pd.DataFrame(data=c_list, columns=['AP', 'Length', 'Type'])
    print(a_df)

    ax = sns.barplot(x="Length", y="AP", hue="Type", data=a_df)
    handles, labels = ax.get_legend_handles_labels()
    plt.xlabel('Peptide Length')
    plt.ylabel('Matthews Correlation Coefficient')
    plt.legend(handles, ['Scavenger', 'Chelator'],loc="upper right")
    plt.savefig(OUT_DIR + 'Individual_mcc_20', bbox_inches='tight')
    #plt.show()


def plotfigure(pred_vec_all, y_test_all, OUT_DIR):

    fpr = dict()
    tpr = dict()
    roc_auc = dict()

    pred1 = [np.array(item[0]) for item in pred_vec_all]
    pred2 = [np.array(item[1]) for item in pred_vec_all]

    a_pred = np.array([pred1, pred2])

    all1 = [np.array(item[0]) for item in y_test_all]
    all2 = [np.array(item[1]) for item in y_test_all]

    y_test_all = np.array([all1, all2])

    plt.figure()
    lw = 2

    for i in range(len(y_test_all)):
        fpr[i], tpr[i], _ = roc_curve(np.array(y_test_all[i]), np.array(a_pred[i]))
        roc_auc[i] = auc(fpr[i], tpr[i])

        plt.plot(fpr[i], tpr[i], color='darkorange', lw=lw, label='FNN: AUC = %0.2f' % roc_auc[i])


    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.savefig(OUT_DIR + '/AUROCplot', bbox_inches='tight')
    #plt.show()
########################################
#####    Not-sure functions      #######
########################################

def Find_Optimal_Cutoff(target, predicted, test, vali, y_num):

    fpr, tpr, threshold = roc_curve(target, predicted)
    i = np.arange(len(tpr))
    roc = pd.DataFrame({'tf' : pd.Series(tpr-(1-fpr), index=i), 'threshold' : pd.Series(threshold, index=i)})
    mcc = []

    aver_prec, best_thres = p_r_curve(target, predicted,test,vali, y_num)

    for num, val in enumerate(threshold):
        tmp = np.array(np.where(predicted >= val, 1, 0))
        mcc.append([matthews_corrcoef(target, tmp, sample_weight=None),val])

    mcc = sorted(mcc, key=lambda x: x[0], reverse=True)

    roc_t = roc.ix[(roc.tf-0).abs().argsort()[:1]]

    optimal_idx = np.argmax(tpr + (1-fpr) - 1)

    Youdens_Index = threshold[optimal_idx]

    return(list(roc_t['threshold'])[0],mcc[0][1],Youdens_Index, aver_prec)
def pred_threshold1(y_true, y_pred, test, vali):

    y_pred = change_order(y_pred)

    y_true = change_order(y_true)

    num_classes = y_true.shape[0]

    sen_spe = []
    mcc_list     = []
    youden_list = []
    aver_prec_list = []
    for i in range(num_classes):

        roc_t,mcc,youden_index, aver_prec = Find_Optimal_Cutoff(y_true[i], y_pred[i], test, vali, i)
        sen_spe.append(roc_t)
        mcc_list += [mcc]
        youden_list.append(youden_index)
        aver_prec_list.append(aver_prec)

    return([sen_spe,mcc_list,youden_list, aver_prec_list])

def pred_threshold(PRED_y, TARGET_y, test, vali):
    best_tres = []

    PRED_y = change_order(PRED_y)
    TARGET_y = change_order(TARGET_y)

    for num, val in enumerate(PRED_y):
        _, best_t = p_r_curve(PRED_y[num], TARGET_y[num], 'Scav', test, vali)
        best_tres += [best_t]

    return (np.array(best_tres))
def change_order(a_nested_array):

    a_array = []

    if np.shape(a_nested_array)[1] < 2:
        a_array.append(np.asarray([np.array(item[0]) for item in a_nested_array]))
        return(np.asarray(a_array))

    for i in range(np.shape(a_nested_array)[1]):
        a_array.append([(item[i]) for item in a_nested_array])

    return (np.array(a_array))
def squeeze(pred):
    pred = np.array(pred)
    pred = np.squeeze(pred)
    return(pred)
def p_r_curve(PRED_y, TARGET_y,test,vali, y_num):

    average_precision = average_precision_score(TARGET_y, PRED_y)
    precision, recall, threshold = precision_recall_curve(TARGET_y, PRED_y)


    optimal_idx = np.argmin(np.abs(precision - recall))

    best_thres = threshold[optimal_idx]

    # In matplotlib < 1.5, plt.fill_between does not have a 'step' argument
    #step_kwargs = ({'step': 'post'}
    #               if 'step' in signature(plt.fill_between).parameters
    #               else {})
    #plt.step(recall, precision, color='b', alpha=0.2, where='post')
    #plt.fill_between(recall, precision, alpha=0.2, color='b', **step_kwargs)

    #plt.xlabel('Recall')
    #plt.ylabel('Precision')
    #plt.ylim([0.0, 1.05])
    #plt.xlim([0.0, 1.0])
    #plt.title('2-class Precision-Recall curve: AP={0:0.2f}'.format(average_precision))
    #plt.savefig('/home/projects/vaccine/people/s132421/Arbejde/Antioxidants/Results/P_R_curve'+str(y_num)+str(test)+str(vali)+'.png', bbox_inches='tight')
    #plt.close()

    return(average_precision, best_thres)