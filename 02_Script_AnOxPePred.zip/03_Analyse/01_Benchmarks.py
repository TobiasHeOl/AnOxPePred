import pandas as pd
import numpy as np
from Bio import pairwise2
import A_Utilities as ut
from sklearn.metrics import average_precision_score, confusion_matrix
import optparse, random, os

parser = optparse.OptionParser()
parser.add_option('-i', default='Partitioned_data.csv', dest='INPUT_FILE', help='Input csv file')
parser.add_option('-o', default='', dest='OUTPUT_DIR', help='Output directory')
(options, args) = parser.parse_args()

IN_FILE = options.INPUT_FILE
OUT_DIR = options.OUTPUT_DIR

data_df = pd.read_csv(IN_FILE, index_col=0)

def calc(tp, fx):
    # Not mathematically correct, but similar to using epsilon
    if tp + fx == 0:
        return (0)
    else:
        return (tp / (tp + fx))


# Load DataFrame into nested lists
PAR_VEC = data_df.loc[:, ['partition']].values
DATA_LIST = data_df.loc[:, ['Sequence']].values
TARGET_Scav = data_df.loc[:, ['Scavenger']].values
TARGET_Chel = data_df.loc[:, ['Chelator']].values

TARGET_y = data_df.loc[:, ['Scavenger', 'Chelator']].values
print(TARGET_y)
print(PAR_VEC)


def align_to_best(SEQ, SEQ_LIST, INDEX=[1]):

    best_id = 0
    best_num = random.choice(INDEX)
    for num in INDEX:
        ident = pairwise2.align.globalms(SEQ, SEQ_LIST[num], 1, 0, -1, -1, penalize_end_gaps=False, score_only=True)
        if ident > best_id:
            best_num = num
            best_id = ident

    return best_num

# Make predictions based on sequence identity
def yield_bench_pred(DATA_LIST, TARGET_y, PAR_VEC):
    for seq, PAR in zip(DATA_LIST, PAR_VEC):

        best_seq = align_to_best(seq, DATA_LIST, INDEX=[num for num, val in enumerate(PAR_VEC) if val != PAR])

        yield TARGET_y[best_seq]


PRED_TARGET = np.stack(yield_bench_pred(DATA_LIST.ravel(), TARGET_y, PAR_VEC.ravel()))


def calc_metrics(PRED_TARGET, TARGET_y):
    # Loop over the predictions for each output and calculate, precision, recall and AP
    for num, val in enumerate(PRED_TARGET):

        average_precision = average_precision_score(TARGET_y[num], PRED_TARGET[num])
        tn, fp, fn, tp = (confusion_matrix(TARGET_y[num], PRED_TARGET[num]).ravel())

        print((confusion_matrix(TARGET_y[num], PRED_TARGET[num]).ravel()))

        R_val = calc(tp, fn)
        P_val = calc(tp, fp)

        print(average_precision)
        print(R_val)
        print(P_val)

        mcc = ut.calc_mcc(np.array(PRED_TARGET[num]), np.array(TARGET_y[num]))
        f1score = ut.calc_f1_score_w_thres(np.array(PRED_TARGET[num]), np.array(TARGET_y[num]), 0.5)

        print(mcc)
        print(f1score)

        yield mcc[0][0], average_precision, R_val, P_val, f1score


a_data = np.stack(calc_metrics(np.stack(zip(*PRED_TARGET)), np.stack(zip(*TARGET_y))))

a_df = pd.DataFrame(data=[['Scavenger'] + a_data[0].tolist(), ['Chelator'] + a_data[1].tolist()],
                    columns=['Type', 'MCC', 'AP', 'Recall', 'Precision', 'f1_score'])


a_df.to_csv(os.path.join(OUT_DIR, 'benchmark_results.csv'))