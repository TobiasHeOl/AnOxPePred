
import pandas as pd
input = r'C:\Users\TobiasHO\Documents\Tmp_files\Deep_tmp\Arbejde\Antioxidants\Scripts\4Website\Results\01_Samples\Potato_21_30\Protein_Chelator_All.txt'


def load_file(input):
    with open(input, 'r') as handle:
        next(handle)
        for line in handle:
            if not line.startswith('Cluster'):
                a_list = line.strip().replace('\t\t\t', '\t').split('\t')
                yield [float(a_list[0]), a_list[1].strip(), a_list[2].strip()]

this_gen = list(load_file(input))

print(this_gen)


this_df = pd.DataFrame(data=this_gen, columns=['score','seq','name'])
print(this_df)

the_list = []
for i in range(21, 31):
    tmp_df = this_df[this_df['seq'].apply(len) == i]
    tmp_df = tmp_df.sort_values(by=['score'], axis=0, ascending=False)
    the_list += tmp_df.head(5).values.tolist()
    tmp_df = tmp_df[this_df['score'] <= 0.01]
    the_list += tmp_df.head(3).values.tolist()

print(the_list)
with open(r'C:\Users\TobiasHO\Documents\Tmp_files\Deep_tmp\Arbejde\Antioxidants\Scripts\printed.txt', 'w') as handle:
    for i in the_list:
        handle.write(str(i[0])+'\t'+str(i[1])+'\t'+i[2]+'\n')


