import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, roc_curve, auc, matthews_corrcoef, f1_score
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import average_precision_score

########################################
##### Performance functions      #######
########################################

def calc_auc(PRED_y, TARGET_y):

    fpr, tpr, _ = roc_curve(np.array(TARGET_y), np.array(PRED_y))
    roc_auc = auc(fpr, tpr)

    return (roc_auc)


def calc_precision_recall(PRED_y, TARGET_y, THRESHOLD):

    BINARY_y = np.where(PRED_y >= THRESHOLD, 1, 0)
    tn, fp, fn, tp = confusion_matrix(np.array(TARGET_y), np.array(BINARY_y)).ravel()

    R_val = calc_pr_eq(tp, fn)
    P_val = calc_pr_eq(tp, fp)

    return (R_val, P_val)


def calc_pr_eq(tp,val):
    # Purpose is to circumventing dividing with 0, but remember it is not mathematically correct
    # if val is fn then it calculates recall, if val is fp it calculates precision
    if tp + val == 0:
        return(0)
    else:
        return(tp / (tp + val))


def calc_AP(PRED_y, TRUE_y):
    _, _, threshold = roc_curve(TRUE_y, PRED_y)

    AP_thres_tmp = []
    for num, thres in enumerate(threshold):
        tmp = np.array(np.where(PRED_y >= thres, 1, 0))
        AP_thres_tmp.append([average_precision_score(TRUE_y, tmp), thres])

    AP_thres = sorted(AP_thres_tmp, key=lambda x: x[0], reverse=True)
    print(AP_thres[-5:])

    return np.array(AP_thres[0])


def calc_mcc(PRED_y, TRUE_y):


    fpr, tpr, threshold = roc_curve(TRUE_y, PRED_y)

    mcc_tmp = []
    for num, val in enumerate(threshold):
        tmp = np.array(np.where(PRED_y >= val, 1, 0))
        mcc_tmp.append([matthews_corrcoef(TRUE_y, tmp, sample_weight=None), val])

    mcc = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)
    print(mcc[-5:])

    return np.array([mcc[0][0]]), np.array([mcc[0][1]])


def calc_f1_score(PRED_y, TRUE_y):
    _, _, thresholds = roc_curve(TRUE_y, PRED_y)

    f1_thres = []
    for num, thres in enumerate(thresholds):
        tmp = np.array(np.where(PRED_y >= thres, 1, 0))
        f1_thres.append([f1_score(TRUE_y, tmp, average='binary'), thres])

    f1_thres = sorted(f1_thres, key=lambda x: x[0], reverse=True)
    print(f1_thres[-5:])

    return np.array([f1_thres[0][0]]), np.array([f1_thres[0][1]])


def calc_mcc_w_thres(PRED_y, TRUE_y, THRES):
    tmp = np.array(np.where(PRED_y >= THRES, 1, 0))
    return matthews_corrcoef(TRUE_y, tmp, sample_weight=None)


def calc_f1_score_w_thres(PRED_y, TRUE_y, THRES):
    tmp = np.array(np.where(PRED_y >= THRES, 1, 0))
    return f1_score(TRUE_y, tmp, average='binary')



########################################
#####        Plot functions      #######
########################################


def plot_BarMultiHandles(a_df, X, Y, HUE, XL, XTL, YL, HUEL, TITLE, OUT_FILE):

    ax = sns.barplot(x=X, y=Y, hue=HUE, data=a_df)
    change_width(ax, .25)
    handles, labels = ax.get_legend_handles_labels()
    plt.xlabel(XL, fontsize=22)
    plt.ylabel(YL, fontsize=22)
    ax.set_title(TITLE, fontsize=24)
    ax.set_ylim(0, 1)
    ax.set_xticklabels(XTL, fontsize=18)
    ax.set_yticklabels([0.0,0.2,0.4,0.6,0.8,1.0], fontsize=18)
    plt.legend(handles, HUEL, loc="upper right", fontsize=18)
    plt.savefig(OUT_FILE, bbox_inches='tight')
    plt.clf()


def individual_performance(PRED_y, TARGET_y, A_DATA_LIST):
    # Make df with Pred, Target
    PRED_DATA = np.array([[PRED_y[num], TARGET_y[num], A_DATA_LIST[num]] for num, val in enumerate(A_DATA_LIST)])

    a_df = pd.DataFrame(PRED_DATA, columns=['Pred', 'Target', 'Sequence'])
    a_df['Length'] = a_df['Sequence'].apply(len)

    # diff_len = [2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    diff_len = list(range(2, 21))

    AP = []
    ROC = []
    mcc = []

    Nr_len = []

    for i in diff_len:
        print(i)
        # Take out only a certain length
        b_df = a_df[a_df['Length'] == i]
        PRED_y = b_df['Pred'].values
        TARGET_y = b_df['Target'].values

        Nr_len.append(len(b_df.index))

        if not list(PRED_y):
            continue

        # Otherwise the array is not 100% an array
        PRED_y = [i for i in PRED_y]
        TARGET_y = [i for i in TARGET_y]

        # Based on when precision and recall is equal
        best_tres = pred_threshold(PRED_y, TARGET_y, 'b', 'c')

        # Change order for the subsequent functions
        PRED_y = change_order(PRED_y)
        TRUE_y = change_order(TARGET_y)

        ROC.append(calc_auc(PRED_y, TRUE_y))
        R_val, P_val = calc_precision_recall(PRED_y, TRUE_y, best_tres)
        AP.append(calc_av_precision(PRED_y, TRUE_y))

        fpr, tpr, threshold1 = roc_curve(TRUE_y[0], PRED_y[0])
        fpr, tpr, threshold2 = roc_curve(TRUE_y[0], PRED_y[0])

        mcc_tmp = []
        for num, val in enumerate(threshold1):
            tmp = np.array(np.where(PRED_y[0] >= val, 1, 0))
            mcc_tmp.append([matthews_corrcoef(TRUE_y[0], tmp, sample_weight=None), val])

        mcc1 = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)

        mcc_tmp = []
        for num, val in enumerate(threshold2):
            tmp = np.array(np.where(PRED_y[1] >= val, 1, 0))
            mcc_tmp.append([matthews_corrcoef(TRUE_y[1], tmp, sample_weight=None), val])

        mcc2 = sorted(mcc_tmp, key=lambda x: x[0], reverse=True)
        mcc.append(np.array([mcc1[0][0], mcc2[0][0]]))

    return (mcc, diff_len)


def change_width(ax, new_value) :
    for patch in ax.patches :
        current_width = patch.get_width()
        diff = current_width - new_value

        # we change the bar width
        patch.set_width(new_value)

        # we recenter the bar
        patch.set_x(patch.get_x() + diff * .5)

