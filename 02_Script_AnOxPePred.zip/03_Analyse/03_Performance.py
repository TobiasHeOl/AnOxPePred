import numpy as np
import pandas as pd
import A_Utilities as ut

INPUT_FILE = r'C:\Users\TobiasHO\Documents\01_Projects\02_Pep_Bioactivity_Pred\03_AnOxPePred\A_AnOxPePred\03_Results_AnOxPePred\02_Model_Params\01_CNN_params_H100_F100_B32_L0.0001\CNN_predictions.txt'
OUT_DIR = ''

with open(INPUT_FILE, 'r') as f:

    a_list = [line.strip('\n').replace('\t\t', '\t').split('\t') for line in f if not line.startswith('#')]


a_df = pd.DataFrame(data=a_list[1:], columns=a_list[0])

Scav_PRED_y = np.array([[float(x)] for x in a_df['ScavPred'].values])
Scav_TARGET_y = np.array([[int(x)] for x in a_df['Scav'].values])

Chel_PRED_y = np.array([[float(x)] for x in a_df['ChelPred'].values])
Chel_TARGET_y = np.array([[int(x)] for x in a_df['Chel'].values])

###################################################
#Scav_mcc = [ut.calc_mcc_w_thres(Scav_PRED_y, Scav_TARGET_y, Scav_threshold)]
#Chel_mcc = [ut.calc_mcc_w_thres(Chel_PRED_y, Chel_TARGET_y, Chel_threshold)]
Scav_mcc, Scav_threshold = ut.calc_mcc(Scav_PRED_y, Scav_TARGET_y)
Chel_mcc, Chel_threshold = ut.calc_mcc(Chel_PRED_y, Chel_TARGET_y)
###################################################


Scav_recall, Scav_precision = ut.calc_precision_recall(np.array(Scav_PRED_y), np.array(Scav_TARGET_y), Scav_threshold)
Chel_recall, Chel_precision = ut.calc_precision_recall(np.array(Chel_PRED_y), np.array(Chel_TARGET_y), Chel_threshold)

Scav_f1 = ut.calc_f1_score_w_thres(np.array(Scav_PRED_y), np.array(Scav_TARGET_y), Scav_threshold)
Chel_f1 = ut.calc_f1_score_w_thres(np.array(Chel_PRED_y), np.array(Chel_TARGET_y), Chel_threshold)

Scav_auc = ut.calc_auc(np.array(Scav_PRED_y), np.array(Scav_TARGET_y))
Chel_auc = ut.calc_auc(np.array(Chel_PRED_y), np.array(Chel_TARGET_y))

a_data = ['AnOxPe_pred', 'Scavenger', Scav_auc, Scav_mcc[0], Scav_threshold[0], Scav_recall, Scav_precision, Scav_f1]
b_data = ['AnOxPe_pred', 'Chelator', Chel_auc, Chel_mcc[0], Chel_threshold[0], Chel_recall, Chel_precision, Chel_f1]

# Benchmark values are taken from benchmark_results.csv file
c_data = ['Sequence-based', 'Scavenger', 'N/A', 0.158162, Scav_threshold[0], 0.071749, 0.551724, 0.12698412698412698]
d_data = ['Sequence-based', 'Chelator', 'N/A', 0.151188, Chel_threshold[0], 0.075000, 0.333333, 0.12244897959183673]

a_df = pd.DataFrame(data=[a_data, b_data, c_data, d_data], columns=['Model', 'Type', 'AUC', 'MCC', 'Threshold', 'Recall', 'Precision', 'f1_score'])

print(a_df)


ut.plot_BarMultiHandles(a_df, X="Type", Y="Recall", HUE="Model", XL='Antioxidant Property', XTL=['FRS', 'Chelator'],
                        YL='Recall', HUEL=['AnOxPePred', 'Sequence Identity-based'], TITLE='(A)',
                        OUT_FILE=OUT_DIR + '02_Recall')
ut.plot_BarMultiHandles(a_df, X="Type", Y="Precision", HUE="Model", XL='Antioxidant Property', XTL=['FRS', 'Chelator'],
                        YL='Precision', HUEL=['AnOxPePred', 'Sequence Identity-based'], TITLE='(B)',
                        OUT_FILE=OUT_DIR + '02_Precision')
ut.plot_BarMultiHandles(a_df, X="Type", Y="f1_score", HUE="Model", XL='Antioxidant Property', XTL=['FRS', 'Chelator'],
                        YL='F1 Score', HUEL=['AnOxPePred', 'Sequence Identity-based'], TITLE='(C)',
                        OUT_FILE=OUT_DIR + '02_F1score')
ut.plot_BarMultiHandles(a_df, X="Type", Y="MCC", HUE="Model", XL='Antioxidant Property', XTL=['FRS', 'Chelator'],
                        YL='MCC', HUEL=['AnOxPePred', 'Sequence Identity-based'], TITLE='(D)',
                        OUT_FILE=OUT_DIR + '02_MCC')

a_df.to_csv('Performance_v2.csv')
