import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import optparse


parser = optparse.OptionParser()
parser.add_option('-i', default=r'C:\Users\TobiasHO\Documents\Tmp_files\Deep_tmp\Arbejde\Antioxidants\Results\01_B_Interesting_peptides\01_GS_Interesting_peptides_100_100_32_001.txt', dest='INPUT_DIR', help='Input directory')
parser.add_option('-o', default='', dest='OUTPUT_DIR', help='Output directory')
(options, args) = parser.parse_args()

IN_DIR = options.INPUT_DIR
OUT_DIR = options.OUTPUT_DIR

chel_data = [['1-gamma', 3.84], ['10-alpha', 7.30], ['12-alpha', -2.1], ['22-beta', 1.37],['36-gamma', 5.64],['38-gamma', -29.57],['40-gamma',-7.6],['52-AMP', -27.05], ['27-beta', 16.96]]
true_data = [['1-gamma', 29.33], ['10-alpha', 30.49], ['12-alpha', 32.07], ['22-beta', 92.53],['36-gamma',29.12],['38-gamma',92.00],['40-gamma',89.37],['52-AMP',90.64]]
Scav_df = pd.DataFrame(data=true_data+[['27-beta', 90.95]], columns=['Name', 'True_Scavenger'])
Chel_df = pd.DataFrame(data=chel_data, columns=['Name', 'True_Chelator'])

with open(IN_DIR, 'r') as f:
    a_list = [line.strip('\n').replace(' ', '\t').replace('\t\t', '\t').split('\t') for num, line in enumerate(f)]
    a_list = [[x for x in val if not x == ''] for num, val in enumerate(a_list)]

    a_df = pd.DataFrame(data=a_list[1:], columns=a_list[0])
    SC_df = a_df.iloc[:, [0, 1, 2]]
    CH_df = a_df.iloc[:, [3, 4, 5]]

SC_df['Scavenger_num'] = pd.to_numeric(SC_df.loc[:, 'Scavenger'], errors='ignore')
CH_df['Chelator_num'] = pd.to_numeric(CH_df.loc[:, 'Chelator'], errors='ignore')


def z_normalize(score, mean, std):
    # Normalizes with the help of z-score
    normalized = (score-mean)/std

    return(normalized)
def measure_emul(score, length ,norm_df, type=0):

    # Pick the right values for normalization
    temp_df = norm_df.loc[norm_df['Length'] == length]

    # Normalize value and save it
    if type == 0:
        score = z_normalize(score, temp_df.iloc[0][1], temp_df.iloc[0][2])
    else:
        score = z_normalize(score, temp_df.iloc[0][3], temp_df.iloc[0][4])

    return(score)

a_df = pd.read_csv(r'C:\Users\TobiasHO\Documents\Tmp_files\Deep_tmp\Arbejde\Antioxidants\Scripts\1PrepareData\AO_norm.csv',index_col=0)

Scav_all = pd.merge(Scav_df, SC_df, how='left', on=['Name'])
Chel_all = pd.merge(Chel_df, CH_df, how='left', on=['Name'])


Scav_all['Value'] = Scav_all.apply(lambda row: measure_emul(row.loc['Scavenger_num'], len(row.loc['Sequence']), a_df, type=0),axis=1)
Chel_all['Value'] = Chel_all.apply(lambda row: measure_emul(row.loc['Chelator_num'], len(row.loc['Sequence']), a_df, type=0),axis=1)

print(Scav_all['Value'].corr(Scav_all['True_Scavenger'], method='spearman'))
print(Chel_all['Value'].corr(Chel_all['True_Chelator'], method='spearman'))

print(Scav_all)

sns.regplot(Scav_all['Value'], Scav_all['True_Scavenger'])
plt.show()
