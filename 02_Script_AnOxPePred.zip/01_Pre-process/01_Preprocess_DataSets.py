import numpy as np
import pandas as pd
import gzip
import argparse
from Bio import pairwise2
import os


# Parse it in
parser = argparse.ArgumentParser()
parser.add_argument('-i', dest='input_data', default='01_raw_In_houseDB.txt', help='Raw_data')
parser.add_argument('-o', dest='out_dir', default='same', help='Output directory path')

# Define the parsed arguments
args = parser.parse_args()
input_data = args.input_data
OUT_DIR = args.out_dir

if OUT_DIR == 'same':
    OUT_DIR = os.path.dirname(input_data)


def homology_reduction(a_df, cutoff):

    a_columns = a_df.columns
    a_list = np.array(a_df).tolist()
    b_list = []
    count=0
    for a_num, a_val in enumerate(a_list):
        count+=1
        print(count)

        if b_list == []:
            b_list.append(a_val)

        else:
            for b_num, b_val in enumerate(b_list):

                match = pairwise2.align.globalms(a_val[0], b_val[0], 1, 0, -1, -1, penalize_end_gaps=False, score_only=True)

                nest_list = [a_val, b_val]
                nest_list.sort(key=lambda x: x[3])

                ident = match / nest_list[1][3]

                if ident >= cutoff:
                    b_list[b_num] = nest_list[1]
                    break

            else:
                b_list.append(a_val)

    b_df = pd.DataFrame(data=b_list, columns=a_columns)

    return(b_df)
def del_redudant(a_list):
    new_list = []
    for i in a_list:
        if i not in new_list:
            new_list += [i]

    return (new_list)
def data_retriver(pos_data):
    p_list = []
    with open(pos_data, 'r') as a_file:
        for line in a_file:
            line = line.split('\t')

            if not line[0].startswith('#'):
                seq = line[0].strip()

                types = line[1].strip().split('|')

                scores = [0, 0]

                for i in types:
                    if i == 'Scavenger' or i == 'ORAC' or i == 'LAPS' or i == 'ABTS':
                        scores[0] = 2

                    elif i == 'Scavenger1' or i == 'ORAC1' or i == 'LAPS1' or i == 'ABTS1':
                        scores[0] = 1

                    elif i == 'Chelator':
                        scores[1] = 2

                    elif i == 'Chelator1':
                        scores[1] = 1

                    elif i == 'NoScavenger':
                        scores[0] = 0

                    elif i == 'NoChelator':
                        scores[1] = 0

                p_list += [[seq] + scores + [len(seq)]]

    return(p_list)
def cut_peptides(pep_dict, number):
    peptide=[]
    peptides = []
    with gzip.open('/home/databases/ncbi-blast/FASTA/nr.gz', 'rb') as f:
        for dict in pep_dict:

            pep_count = 0
            pep_len = dict
            pep_num = pep_dict[dict]*number

            for line in f:

                if pep_count >= pep_num:
                    peptides += peptide[:pep_num]
                    peptide = []
                    break

                elif line.isupper()==True and len(line)>30:
                    seq = line.strip().decode('utf-8')

                    for i in range(int(len(seq)/pep_len)):
                        peptide += [[seq[i*pep_len:i*pep_len+pep_len],0,0,len(seq[i*pep_len:i*pep_len+pep_len])]]
                        pep_count +=1

    return(peptides)
def same_length(pep_dict, number):
    peptide=[]
    peptides = []
    with gzip.open('/home/databases/ncbi-blast/FASTA/nr.gz', 'rb') as f:
        for dict in pep_dict:

            pep_count = 0
            pep_len = dict
            pep_num = number

            for line in f:

                if pep_count >= pep_num:
                    peptides += peptide[:pep_num]
                    peptide = []
                    break

                elif line.isupper()==True and len(line)>30:
                    seq = line.strip().decode('utf-8')

                    for i in range(int(len(seq)/pep_len)):
                        peptide += [[seq[i*pep_len:i*pep_len+pep_len],0,0,len(seq[i*pep_len:i*pep_len+pep_len])]]
                        pep_count +=1

    return(peptides)

# Load data
a_list = data_retriver(input_data)

# Remove 100% identical data
a_list = del_redudant(a_list)

# Create DataFrame with true values
a_df = pd.DataFrame(a_list, columns=['Sequence', 'Scavenger', 'Chelator', 'Length'])
a_df.loc[:, 'Type'] = 'TRUE'

# Change 1's to either negatives or positives (stay 1 or change to 0)
a_df = a_df.replace({'Scavenger': 1, 'Chelator': 1}, 1)
# Change 2's to 1's
a_df = a_df.replace({'Scavenger': 2, 'Chelator': 2}, 1)

# Take out data with the same target, and do homology reduction with a defined threshold (90% default)
tmp1_df = a_df[a_df['Scavenger'].isin([1])]
tmp2_df = a_df[~a_df['Scavenger'].isin([1]) & a_df['Chelator'].isin([1])]
tmp3_df = a_df[~a_df['Scavenger'].isin([1]) & ~a_df['Chelator'].isin([1])]

tmp1_df = homology_reduction(tmp1_df, cutoff=0.9)
tmp2_df = homology_reduction(tmp2_df, cutoff=0.9)
tmp3_df = homology_reduction(tmp3_df, cutoff=0.9)


# Make a dictionary with the number of positives at the different lengths
# (used to decide how many negatives of each length)
unique, counts = np.unique(np.array(tmp1_df['Length']), return_counts=True)
len_dict = dict(zip(unique, counts))
#len_dict = dict(zip(np.array(range(2, 37)), np.array(range(2, 37))))

# Concatenate the DataFrames back together
a_df = pd.concat([tmp1_df, tmp2_df, tmp3_df])

# Choose how many random negatives for each positives (use a ratio (1x5) or a constant (100))
r_list = cut_peptides(len_dict, 10)

# Remove 100% identical random negatives and save them in DataFrame
r_list = del_redudant(r_list)
r_df = pd.DataFrame(data=r_list, columns=['Sequence', 'Scavenger', 'Chelator', 'Length'])
r_df.loc[:, 'Type'] = 'RANDOM'

# Homology reduction with a defined threshold (90% default)
r_df = homology_reduction(r_df, cutoff=0.9)

# Remove random negatives which are present in a_df (ever point which is present more than once is removed completely)
r_df = pd.concat([r_df, a_df, a_df]).drop_duplicates(subset=['Sequence'], keep=False)

# Take only 100 - makes sure it is the same number, even after homology reduction and deletion of redundant.
n_df = pd.DataFrame(columns=['Sequence', 'Scavenger', 'Chelator', 'Length', 'Type'])
for i in range(2, 40):
    tmp_df = r_df.loc[r_df['Length'] == i]
    n_df = pd.concat([n_df, tmp_df.iloc[0:100]], sort=True)


data_df = pd.concat([a_df, n_df], sort=False, ignore_index=True)

data_df.to_csv(OUT_DIR+'/ProcessedData.csv', encoding='utf-8')