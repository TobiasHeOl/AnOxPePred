import numpy as np
import pandas as pd

INPUT_FILE = r'C:\Users\TobiasHO\Documents\Tmp_files\Deep_tmp\Arbejde\Antioxidants\Input_data\randompeptide30000.fsa'

def convert_fsa_list(fasta_file):
    with open(fasta_file, 'r') as a_f:
        for line in a_f:
            if line.startswith('>'):
                yield [line[1:].strip()]
            else:
                yield [line.strip()]
def protein_chop1(seq_array, pep_length=10):
    for seq_num, seq in enumerate(seq_array):
        for res_num, res in enumerate(seq):
            if res_num + pep_length <= len(seq):
                yield seq[res_num:(res_num + pep_length)]
def protein_chop(seq_array, pep_length=10, diff=True):
    for seq_num, seq in enumerate(seq_array):
        seq_range = range(0, len(seq), pep_length) if diff is True else range(len(seq))
        for res_num in seq_range:
            if res_num + pep_length <= len(seq):
                yield seq[res_num:(res_num + pep_length)]

input = np.stack(convert_fsa_list(INPUT_FILE)).reshape(-1, 2)



with open('Random_peptides2.fsa', 'w') as f:

    for i in range(2, 31):
        chop = protein_chop([input[0][1]], pep_length=i, diff=True)

        for peptide in chop:
            f.write('>peptide\n')
            f.write(peptide+'\n')



