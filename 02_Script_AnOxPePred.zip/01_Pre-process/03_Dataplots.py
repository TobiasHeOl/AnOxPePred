import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
import os

# Parse it in
parser = argparse.ArgumentParser()
parser.add_argument('-i', dest='input_data', default=r'C:\Users\TobiasHO\Documents\Tmp_files\02_B_processed_data.csv', help='Raw_data')
parser.add_argument('-o', dest='out_dir', default='same', help='Output directory path')

# Define the parsed arguments
args = parser.parse_args()
input_data = args.input_data
OUT_DIR = args.out_dir

if OUT_DIR == 'same':
    OUT_DIR = os.path.dirname(input_data)

name = os.path.split(input_data)
name = os.path.splitext(name[1])[0]

def length_prepare_data(a_df):

    diff_len = list(range(2, 37))

    Scavenger = []
    Chelator = []
    NegaScav = []
    NegaChel = []

    a_df = a_df[a_df['Type'] == 'TRUE']

    for i in diff_len:
        # Take out only a certain length
        b_df = a_df[a_df['Length'] == i]

        Scavenger.append(len(b_df[b_df['Scavenger'] == 1].index))
        Chelator.append(len(b_df[b_df['Chelator'] == 1].index))
        NegaScav.append(len(b_df[b_df['Scavenger'] == 0].index))
        NegaChel.append(len(b_df[b_df['Chelator'] == 0].index))

    a_list = [[val, diff_len[num], 'Scavenger'] for num, val in enumerate(Scavenger)]
    b_list = [[val, diff_len[num], 'Chelator'] for num, val in enumerate(Chelator)]
    c_list = [[val, diff_len[num], 'NegaScav'] for num, val in enumerate(NegaScav)]
    d_list = [[val, diff_len[num], 'NegaChel'] for num, val in enumerate(NegaChel)]
    x_list = a_list + b_list + c_list + d_list

    a_df = pd.DataFrame(data=x_list, columns=['Count', 'Length', 'Type'])

    return(a_df)

def plot_individual_pos(a_df, OUT_DIR, name):
    tmp_df = a_df[a_df['Type'].isin(['Scavenger']) | a_df['Type'].isin(['Chelator'])]
    ax = sns.barplot(x="Length", y="Count", hue="Type", data=tmp_df)
    handles, labels = ax.get_legend_handles_labels()
    plt.xlabel('Peptide Length')
    plt.ylabel('Peptide Count')
    plt.legend(handles, ['Scavenger', 'Chelator'], loc="upper right")
    plt.savefig(os.path.join(OUT_DIR, name + '_pos.svg'), format='svg', dpi=1000)
    plt.close()

def plot_individual_neg(a_df, OUT_DIR, name):
    tmp_df = a_df[a_df['Type'].isin(['NegaScav']) | a_df['Type'].isin(['NegaChel'])]
    ax = sns.barplot(x="Length", y="Count", hue="Type", data=tmp_df)
    handles, labels = ax.get_legend_handles_labels()
    plt.xlabel('Peptide Length')
    plt.ylabel('Peptide Count')
    plt.legend(handles, ['Scavenger', 'Chelator'], loc="upper right")
    plt.savefig(os.path.join(OUT_DIR, name + '_neg.svg'), format='svg', dpi=1000)
    plt.close()

data_df = pd.read_csv(input_data, index_col=0)
# Hard coding part - normalizes data
length_df = length_prepare_data(data_df)

# Plot data
plot_individual_pos(length_df, OUT_DIR, name)
plot_individual_neg(length_df, OUT_DIR, name)



