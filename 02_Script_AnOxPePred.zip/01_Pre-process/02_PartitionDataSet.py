import pandas as pd
import numpy as np
from Bio import pairwise2
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument('-i', dest='INPUT_FILE', default='processed_data.csv', help='Input file (.csv)')
parser.add_argument('-o', dest='OUT_DIR', default='same', help='Output dir')

args = parser.parse_args()
INPUT_FILE = args.INPUT_FILE
OUT_DIR = args.OUT_DIR

if OUT_DIR == 'same':
    OUT_DIR = os.path.dirname(INPUT_FILE)

def best_in_nlist(seq1, b_list, cut):
    best_match = 0
    best_num = -1
    for num, grp in enumerate(b_list):

        for seq2 in grp:

            match = pairwise2.align.globalms(seq1[0], seq2[0], 1, 0, -1, -1, penalize_end_gaps=False, score_only=True)
            min_len = min([len(seq1[0]), len(seq2[0])])
            ident = match / min_len

            if ident == 1:
                return(num)

            elif ident > cut:
                if ident > best_match:
                    best_match = ident
                    best_num = num

    return(best_num)


def homology_partition(a_list, ident, cutoff):

    all_sort = sorted(a_list, key=lambda x: len(x[0]), reverse=True)

    b_list_long = []
    b_list_short = []
    count = 0
    for num, seq in enumerate(all_sort):
        count +=1
        print(count)

        if len(seq[0])> int(cutoff):
            if b_list_long == []:
                b_list_long += [[seq]]

            else:
                best_num = best_in_nlist(seq, b_list_long, ident)
                if best_num < 0:
                    b_list_long += [[seq]]
                else:
                    b_list_long[best_num] += [seq]
        else:
            if b_list_short == []:
                b_list_short += [[seq]]

            else:
                best_num = best_in_nlist(seq, b_list_short, ident)
                if best_num < 0:
                    b_list_short += [[seq]]
                else:
                    b_list_short[best_num] += [seq]

    b_list = b_list_long + b_list_short

    return(b_list)


def group_partition(hom_list, part_num):

    hom_list = sorted(hom_list, key=len, reverse=True)

    count = 0
    par_list = [[], [], [], [], []]
    for num, val in enumerate(hom_list):

        if len(val)>3:
            print(len(val))


        par_list[num - count] += val

        # Turn list around when to the end of it (snake method)
        if (num + 1) % part_num == 0:
            count += part_num
            par_list = par_list[::-1]


    # Counts the number of positives and total number of peptides in each partition
    for i in par_list:
        count = 0
        count1 = 0
        count2 = 0
        count3 = 0
        for j in i:

            if j[1] == 1:
                count += 1

            if j[2] == 1:
                count2 += 1

            if len(j[0]) >= 5:
                count1 += 1

            if j[4] == 'TRUE':
                count3 += 1

        print('Number in: ' + str(len(i)))
        print('Positives Scavenger: ' + str(count))
        print('Positives Chelator: ' + str(count2))
        print('Over 5 length: ' + str(count1))
        print('TRUE: ' + str(count3))

    PAR_LIST = []
    DATA_LIST = []
    TARGET_Scav = []
    TARGET_Chel = []
    TYPE = []
    for num, val in enumerate(par_list):
        [PAR_LIST.append(num) for j in val]
        [DATA_LIST.append(j[0]) for j in val]
        [TARGET_Scav.append(j[1]) for j in val]
        [TARGET_Chel.append(j[2]) for j in val]
        [TYPE.append(j[4]) for j in val]

    return(PAR_LIST, DATA_LIST, TARGET_Scav, TARGET_Chel, TYPE)

# Load DataFrame
data_df = pd.read_csv(INPUT_FILE, index_col=0)

# Take out data with lengths 2-20 and turn it into a list
data_list = np.array(data_df[data_df['Length'].isin(list(range(2, 40)))]).tolist()

# Make groups with 70% identity  || Cutoff is a divide in the data homology based on sequence length
homology_list = homology_partition(data_list, ident=0.7, cutoff=0)

# Fit groups into 5 partitions
PAR_VEC, DATA_LIST, TARGET_Scav, TARGET_Chel, TYPE = group_partition(homology_list, part_num=5)

# Save into DataFrame
data_df = pd.DataFrame({'Sequence': DATA_LIST, 'Scavenger': TARGET_Scav, 'Chelator': TARGET_Chel, 'partition': PAR_VEC})
data_df.to_csv(os.path.join(OUT_DIR, 'Partition_ata.csv'), encoding='utf-8')


