import pandas as pd
import numpy as np

#####################################
#a_DATA = np.stack(zip(*a_DATA))
#a_df = pd.DataFrame(data=a_DATA[1], columns=['Sequence'])
#b_df = pd.DataFrame(columns=['Sequence'])
#for i in range(2, 31):
#    tmp_df = a_df[a_df['Sequence'].apply(len) == i][0:1000]
#    b_df = pd.concat([b_df, tmp_df])
#b_df = b_df.reset_index(drop=True)
#a_DATA = [np.stack(b_df.index), b_df.values.ravel()]
###########################################



INPUT_FILE = r'C:\Users\TobiasHO\Documents\Tmp_files\Deep_tmp\Arbejde\Antioxidants\Results\Normalizationcsv.csv'

a_df = pd.read_csv(INPUT_FILE)

a_df = a_df.iloc[:,1:3]

a_df['Length'] = a_df.iloc[:,1].str.len()

# new data frame with split value columns
new = a_df.iloc[:, 0].str.split(",", n = 1, expand = True)
Scav = new.iloc[:, 0].str.replace('[', '').str.strip().astype(float)
Chel = new.iloc[:, 1].str.replace(']', '').str.strip().astype(float)
print(Chel)

RESULT_array = pd.concat([Scav, Chel, a_df['Length']], axis=1)
print(RESULT_array[RESULT_array['Length'] == 2])
print(RESULT_array)

a_df = pd.DataFrame(columns=['Length','Scav_Mean', 'Scav_Std', 'Chel_Mean', 'Chel_Std'])
for i in range(2, 31):
    tmp_df = RESULT_array[RESULT_array['Length'] == i]
    a_df = pd.concat([a_df, pd.DataFrame(data=[[i, np.mean(tmp_df.iloc[:, 0].values), np.std(tmp_df.iloc[:,0].values),
                                                np.mean(tmp_df.iloc[:, 1].values), np.std(tmp_df.iloc[:, 1].values)]],
                                         columns=['Length', 'Scav_Mean', 'Scav_Std', 'Chel_Mean', 'Chel_Std'])], sort=False)

a_df.to_csv('AO_norm.csv')

