from Bio import pairwise2
import os
import numpy as np
import tensorflow as tf
import pandas as pd
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

####################################
#  Input functions
####################################


def convert_fsa_list(fasta_file):
    with open(fasta_file, 'r') as handle:
        yield [next(handle)[1:].strip()]
        seq = []
        for line in handle:
            if line.startswith('>'):
                yield [''.join(seq)]
                seq = []
                yield [line[1:].strip()]

            else:
                seq += [line.strip()]

        yield [''.join(seq)]


def zscale_read1(zscale):
    with open(zscale, 'r') as f:
        z_dic = {}
        for line in f:
            line = line.split()
            z_dic[line[0]] = [float(line[1]), float(line[2]), float(line[3]), float(line[4]), float(line[5])]
    return z_dic


def zscale_read(AA_scale):
    with open(AA_scale, 'r') as f:
        z_dic = {}
        for line in f:
            if not line.startswith('#'):
                line = line.split()
                z_dic[line[0]] = [float(i) for i in line[1:]]

    return z_dic


def give_score(a_array, score_dic):
    for i in a_array:
        tmp_list = []
        for j in i:
            tmp_list += [score_dic[j]]
        yield tmp_list


def seq_budding(a_array, length='max'):
    if length == 'max':
        max_l = len(max(a_array, key=len))
    else:
        max_l = int(length)

    for num, val in enumerate(a_array):
        if len(val) <= max_l:
            num_x = (max_l - len(val))
            # Put X's on both sides of the sequence
            yield ('X' * int(np.ceil(num_x / 2))) + val + ('X' * int(np.floor(num_x / 2)))


def remove_element(a_str, a_list):
    for element in a_list:
        a_str = a_str.replace(element, '')
    return a_str

######################################
#  Pre-processing functions
######################################


def protein_chop(name_array, seq_array, pep_length):
    for seq_num, seq in enumerate(seq_array):
        for res_num, res in enumerate(seq):
            if res_num + pep_length <= len(seq):
                yield [name_array[seq_num], seq[res_num:(res_num + pep_length)]]


def seq_chop(seq, pep_len=10):
    for res_num, res in enumerate(seq):
        if res_num + pep_len <= len(seq):
            yield seq[res_num:(res_num + pep_len)]


def outer_seq_chop(name_list, seq_list, pep_len=10):
    for name_seq in zip(name_list, seq_list):
        chopped = list(seq_chop(name_seq[1], pep_len))

        if not chopped:
            break
        yield from zip([name_seq[0]] * len(chopped), chopped)


def outer_protein_chop(a_DATA, cut_range):

    pep_NAME = []
    pep_DATA = []
    for cut_len in cut_range:

        # Chops proteins into peptides of specified length
        chopped_peptides = list(outer_seq_chop(a_DATA[0], a_DATA[1], cut_len))

        # Groups identical sequences
        grouped_peptides = switch_dictionary(chopped_peptides)

        pep_NAME += grouped_peptides[0]
        pep_DATA += grouped_peptides[1].tolist()

    return [pep_NAME, pep_DATA]


def switch_dictionary(a_array):
    a_df = pd.DataFrame(data=a_array, columns=['AC', 'Sequence'])
    a_df = a_df.groupby(['Sequence'])['AC'].apply('*a/'.join).reset_index()
    return [ACs.split('*a/') for ACs in a_df['AC'].values], a_df['Sequence'].values


def del_redundant(a_list):
    new_list = []
    for i in a_list:
        if i not in new_list:
            new_list += [i]

    return new_list


def calc_ident(seq1, seq2, min_len=False):
    ident = pairwise2.align.globalms(seq1, seq2, 1, 0, -1, -1, penalize_end_gaps=False, score_only=True)

    if min_len == True:
        min_len = min([len(seq1), len(seq2)])
        ident = ident / min_len

    return ident


def homology_partition(a_LIST, ident=0.7, key=None):
    # Sort so longest peptides are first and make it into a DataFrame
    a_df = pd.DataFrame(data=sorted(a_LIST, key=lambda x: len(x[key]), reverse=True))

    def inner_homology(in_df, ident, key, loops=1):
        tmp_df = in_df.iloc[[0]]
        out_df = pd.DataFrame(data=None, columns=tmp_df.columns)

        for loop in range(loops):

            # Take out every peptide with specified identity to the first peptide in the cluster
            tmp_out_df = in_df.loc[in_df[key].apply(lambda x: calc_ident(x, tmp_df[key].values[0], min_len=True)) >= ident]
            out_df = pd.concat([out_df, tmp_out_df])
            in_df = in_df.drop(tmp_out_df.index).reset_index(drop=True)

            if out_df.shape[0] > loop:
                tmp_df = out_df.iloc[[loop]]

        return out_df, in_df

    # Loop until all peptides in start DataFrame has been put into a cluster
    while a_df.shape[0] >= 1:

        b_df, a_df = inner_homology(a_df, ident, key, loops=10)
        # Yield the cluster and continue
        yield b_df.values


########################################
#         Prediction
########################################


def build_CNN(n_features, n_targets, n_hid, n_filters):
    # input:
    l_in_data = tf.placeholder(tf.float32, shape=[None, None, n_features])
    mode = tf.placeholder(tf.string)
    l_in_data_dropout = tf.layers.dropout(inputs=l_in_data, rate=0.15, training='TRAIN' == mode)

    # Convolutional layers on peptide:
    l_conv_data_1 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=1,
                                     kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False),
                                     padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_3 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=3,
                                     kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False),
                                     padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_5 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=5,
                                     kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False),
                                     padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_7 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=7,
                                     kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False),
                                     padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_9 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=9,
                                     kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False),
                                     padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_11 = tf.layers.conv1d(inputs=l_in_data_dropout, filters=n_filters, kernel_size=11,
                                      kernel_initializer=tf.contrib.layers.xavier_initializer(uniform=False),
                                      padding="same", activation=tf.nn.leaky_relu)
    l_conv_data_1_dropout = tf.layers.dropout(inputs=l_conv_data_1, rate=0.1, training='TRAIN' == mode)
    l_conv_data_3_dropout = tf.layers.dropout(inputs=l_conv_data_3, rate=0.1, training='TRAIN' == mode)
    l_conv_data_5_dropout = tf.layers.dropout(inputs=l_conv_data_5, rate=0.1, training='TRAIN' == mode)
    l_conv_data_7_dropout = tf.layers.dropout(inputs=l_conv_data_7, rate=0.1, training='TRAIN' == mode)
    l_conv_data_9_dropout = tf.layers.dropout(inputs=l_conv_data_9, rate=0.1, training='TRAIN' == mode)
    l_conv_data_11_dropout = tf.layers.dropout(inputs=l_conv_data_11, rate=0.1, training='TRAIN' == mode)

    # max pooling:
    l_pool_max_1 = tf.reduce_max(l_conv_data_1_dropout, axis=1)
    l_pool_max_3 = tf.reduce_max(l_conv_data_3_dropout, axis=1)
    l_pool_max_5 = tf.reduce_max(l_conv_data_5_dropout, axis=1)
    l_pool_max_7 = tf.reduce_max(l_conv_data_7_dropout, axis=1)
    l_pool_max_9 = tf.reduce_max(l_conv_data_9_dropout, axis=1)
    l_pool_max_11 = tf.reduce_max(l_conv_data_11_dropout, axis=1)

    # concatenate:
    l_conc = tf.concat([l_pool_max_1, l_pool_max_3, l_pool_max_5, l_pool_max_7, l_pool_max_9, l_pool_max_11], axis=1)

    # dense hidden layer:
    l_dense = tf.layers.dense(inputs=l_conc, units=n_hid, activation=tf.nn.sigmoid,
                              kernel_initializer=tf.glorot_normal_initializer())
    dropout = tf.layers.dropout(inputs=l_dense, rate=0.4, training='TRAIN' == mode)

    # output layer: (There shouldn't be used an activation function here,
    # as tf cross entropy functions always have a build in activation function)
    yhat = tf.layers.dense(inputs=dropout, units=n_targets, activation=None,
                           kernel_initializer=tf.glorot_normal_initializer())

    return yhat, l_in_data, mode


def predictor(DATA_X, PARAM_dir):
    all_pred = []
    for path in os.listdir(PARAM_dir):
        if path.startswith('params'):

            # set up network:
            hyper_params = np.load(os.path.join(PARAM_dir, path))['arr_1']
            N_FEATURES = int(hyper_params[0])
            N_HID = int(hyper_params[1])
            N_FILTERS = int(hyper_params[2])
            N_TARGETS = 2

            yhat, l_in_data, mode = build_CNN(n_features=N_FEATURES, n_targets=N_TARGETS, n_hid=N_HID,
                                              n_filters=N_FILTERS)

            yhat = tf.sigmoid(yhat)

            # start tf session:
            sess = tf.Session()
            sess.run(tf.global_variables_initializer())

            # set parameters:
            best_params = np.load(os.path.join(PARAM_dir, path))['arr_0']
            params = tf.trainable_variables()
            for i in range(0, len(params)):
                sess.run(params[i].assign(best_params[i]))

            all_pred.append(sess.run(yhat, feed_dict={l_in_data: DATA_X, mode: 'TEST'}))

            # close session:
            sess.close()
            tf.reset_default_graph()

    return all_pred


def peptide_predict1(zscale, a_DATA, PARAM_dir):

    # Represent each amino acid with scale
    z_dic = zscale_read(zscale)
    X_DATA = np.stack(seq_budding(a_DATA[1], length='max'))

    X_DATA = np.stack(give_score(X_DATA, z_dic))

    # Make predictions
    ALL_PRED = predictor(X_DATA, PARAM_dir)
    # calculate mean predictions of all models:
    Y_PRED = np.mean(np.array(ALL_PRED), axis=0).tolist()

    Y_PRED = np.stack(zip(Y_PRED, a_DATA[1], a_DATA[0]))

    print(len(Y_PRED))

    return Y_PRED


def peptide_predict(zscale, a_DATA, PARAM_dir, p_nr):

    # Represent each amino acid with scale
    z_dic = zscale_read(zscale)
    X_DATA = np.stack(seq_budding(a_DATA[1], length='max'))

    X_DATA = np.stack(give_score(X_DATA, z_dic))

    def outer_predictor(X_DATA, PARAM_dir, p_nr=3000):
        for i in range(0, len(X_DATA), p_nr):
            # Make predictions
            ALL_PRED = predictor(X_DATA[i:i+p_nr], PARAM_dir)
            # calculate mean predictions of all models:
            yield np.mean(np.array(ALL_PRED), axis=0).tolist()

    Y_PRED = [i for j in outer_predictor(X_DATA, PARAM_dir, p_nr) for i in j]

    Y_PRED = np.stack(zip(Y_PRED, a_DATA[1], a_DATA[0]))

    return Y_PRED

########################################
#       Output functions
########################################
# Hard coded output files


def pep_save_allAO(Scav, Chel, OUT_PATH, NAMES):

    def B_write(name, result_list, OUT_PATH, val=0):
        def A_write(a_list, num, val):
            f.write(str(a_list[num][0][val])[0:7] + '\t\t' + "{:<31}".format(str(a_list[num][1])) + '\t' +
                    str(' '.join(sorted(a_list[num][2]))) + '\n')

        with open(os.path.join(OUT_PATH, name + str('_All.txt')), 'w') as f:
            f.write(name + '\t' + "{:<31}".format('Sequence') + '\tName\n')
            [A_write(result_list, num, val) for num in range(len(result_list))]

    B_write(NAMES[0], Scav, OUT_PATH, val=0)
    B_write(NAMES[1], Chel, OUT_PATH, val=1)


def pep_save_topAO(Scav, Chel, nr_top, OUT_PATH, NAMES):

    def B_write(name, result_list, OUT_PATH, nr_top, val=0):
        def A_write(a_list, num, val):
            f.write(str(a_list[num][0][val])[0:7] + '\t\t' + "{:<31}".format(str(a_list[num][1])) + '\t' +
                    str(' '.join(sorted(a_list[num][2]))) + '\n')

        with open(os.path.join(OUT_PATH, name + str('_Top.txt')), 'w') as f:
            f.write(name + '\t' + "{:<31}".format('Sequence') + '\tName\n')
            [A_write(result_list, num, val) for num in range(int(nr_top)) if num + 1 <= len(result_list)]


    B_write(NAMES[0], Scav, OUT_PATH, nr_top, val=0)
    B_write(NAMES[1], Chel, OUT_PATH, nr_top, val=1)


def prot_clust_topAO(Scav, Chel, nr_top, OUT_PATH, NAMES):

    def B_write(name, result_list, OUT_PATH, nr_top, val=0):
        def A_write(a_list, num, val):
            f.write(str(a_list[num][0][val])[0:7] + '\t\t' + "{:<31}".format(str(a_list[num][1])) + '\t' +
                    str(' '.join(sorted(a_list[num][2]))) + '\n')
        with open(os.path.join(OUT_PATH, name + str('_Top.txt')), 'w') as f:
            f.write(name+'\t' + "{:<31}".format('Sequence') + '\tName\n')

            for list_NUM, out_result in enumerate(result_list):
                f.write('Cluster: ' + str(list_NUM) + ' size: ' + str(len(result_list[list_NUM])) + '\n')
                [A_write(result_list[list_NUM], num, val) for num in range(int(nr_top)) if num + 1 <= len(result_list[list_NUM])]

    B_write(NAMES[0], Scav, OUT_PATH, nr_top, val=0)
    B_write(NAMES[1], Chel, OUT_PATH, nr_top, val=1)


def prot_save_allAO(Scav, Chel, OUT_PATH, NAMES):

    def B_write(name, result_list, OUT_PATH, val=0):
        def A_write(a_list, num, val):
            f.write(str(a_list[num][0][val])[0:7] + '\t\t' + "{:<31}".format(str(a_list[num][1])) + '\t' +
                    str(' '.join(sorted(a_list[num][2]))) + '\n')
        with open(os.path.join(OUT_PATH, name + str('_All.txt')), 'w') as f:
            f.write(name+'\t' + "{:<31}".format('Sequence') + '\tName\n')

            for list_NUM, out_result in enumerate(result_list):
                f.write('Cluster: ' + str(list_NUM) + ' size: ' + str(len(result_list[list_NUM])) + '\n')
                [A_write(result_list[list_NUM], num, val) for num in range(len(result_list[list_NUM]))]

    B_write(NAMES[0], Scav, OUT_PATH,val=0)
    B_write(NAMES[1], Chel, OUT_PATH, val=1)

########################################
#       Debug functions
########################################


def check_length(a_DATA):
    for peptide in a_DATA[1]:
        if len(peptide) >= 31 or len(peptide) <= 1:
            print("A sequence is outside the limit of 2-30 AA's")
            exit()


def check_pep_len(P_LEN_MIN, P_LEN_MAX):
    if P_LEN_MAX-P_LEN_MIN < 0:
        print('Max peptide length cannot be shorter than Min peptide length.')
        exit()
    if P_LEN_MAX >= 31 or P_LEN_MAX <= 1:
        print("Max peptide length is outside the limit of 2-30 AA's")
        exit()
    if P_LEN_MIN >= 31 or P_LEN_MIN <= 1:
        print("Min peptide length is outside the limit of 2-30 AA's")
        exit()


def check_characters(a_DATA):
    # Define the correct characters (the 20 normal natural aa's)
    AAs20 = 'ARNDCEQGHILKMFPSTWYVX'
    for sequence in a_DATA[1]:
        for res in sequence:
            if res not in AAs20:
                print('Unorthodox character "' + res + '", present in the following sequence.')
                print(sequence)
                exit()


def check_fasta(filename):
    with open(filename, "r") as handle:
        if not next(handle).startswith('>'):
            print('Fasta file starts with no heading.')
            exit()
        switch = 1
        for line in handle:
            if line.startswith('>'):
                if switch == 1:
                    print('Fasta contains a heading with no sequence.')
                    exit()
                else:
                    switch = 1
            else:
                switch = 0


def check_if_int(a_list):
    for element in a_list:
        try:
            yield int(element)
        except ValueError:
            print('An integer variable was giving a non-integer value.')
            print('Floats are not accepted either.')
            exit()


def check_int_in_interval(a_int, min_nr, max_nr, name):
    if int(a_int) > max_nr or int(a_int) < min_nr:
        print(name + " is outside the limit of " + str(min_nr) + '-' + str(max_nr) + '.')
        exit()


def check_if_proteases(protease_list):
    if sum(protease_list) == 0:
        print('No protease has been chosen.')
        print('Please choose at least one when using the proteolysis option.')
        exit()


def web_out_true(web_out, if_web):
    if if_web == 'True':
        if web_out == '':
            print('web_out has to be defined when if_web is True.')
            exit()

########################################
#         Proteolysis functions
########################################


def Trypsin(sequence):
    # Rules defined from https://web.expasy.org/peptide_cutter/peptidecutter_enzymes.html#Tryps
    sequence = 'X' + sequence + 'X'
    for num, res in enumerate(sequence):
        if res in ['R', 'K']:
            if sequence[num + 1] in ['P']:
                if sequence[num - 1:num + 2] in ['MRP', 'WKP']:
                    yield num
            elif sequence[num - 1:num + 2] not in ['CKD', 'DKD', 'CKH', 'CKY', 'CRK', 'RRH', 'RRR']:
                yield num


def Chymotrypsin_high_spec(sequence):
    # Rules defined from https://web.expasy.org/peptide_cutter/peptidecutter_enzymes.html#Tryps
    sequence = sequence + 'X'
    for num, res in enumerate(sequence):
        if res in ['F', 'Y', 'W']:
            if sequence[num + 1] in ['P']:
                pass
            elif sequence[num:num + 2] not in ['WM']:
                yield num + 1


def Chymotrypsin_low_spec(sequence):
    # Rules defined from https://web.expasy.org/peptide_cutter/peptidecutter_enzymes.html#Tryps
    sequence = sequence + 'X'

    for num, res in enumerate(sequence):

        if res in ['F', 'Y', 'W', 'L', 'M', 'H']:
            if sequence[num + 1] in ['P']:
                pass
            elif sequence[num:num + 2] not in ['WM', 'MY', 'HD', 'HM', 'HW']:

                yield num + 1


def Pepsin_over_2pH(sequence):
    # Rules defined from https://web.expasy.org/peptide_cutter/peptidecutter_enzymes.html#Tryps
    sequence = 'XXX' + sequence + 'XXX'

    for num, res in enumerate(sequence):

        if res in ['F', 'Y', 'W', 'L']:
            try:
                if (not sequence[num - 2] in ['P']) and (not sequence[num + 1] in ['P']) and (
                not sequence[num - 1] in ['R']) and (not sequence[num - 3] in ['H', 'K', 'R']):
                    yield num - 3

                if (not sequence[num + 2] in ['P']) and (not sequence[num - 1] in ['P']) and (
                not sequence[num - 2] in ['H', 'K', 'R']):
                    yield num - 2
            except IndexError:
                print('oh')


def proteolysis(sequence, trypsin=1, chytryp_h=0, chytryp_l=0, pepsin=0):
    # Switch for which enzymes to use for proteolysis
    if trypsin == 1:
        yield from Trypsin(sequence)
    if chytryp_h == 1:
        yield from Chymotrypsin_high_spec(sequence)
    if chytryp_l == 1:
        yield from Chymotrypsin_low_spec(sequence)
    if pepsin == 1:
        yield from Pepsin_over_2pH(sequence)


def outer_protein_cleave(a_DATA, min_len, max_len, trypsin=1, chytryp_h=0, chytryp_l=0, pepsin=0):
    # Go through each sequence (protein)
    for num, sequence in enumerate(a_DATA[1]):
        # Find cleaving sites with selected enzymes and remove redundancy
        cleave_sites = del_redundant(list(proteolysis(sequence, trypsin, chytryp_h, chytryp_l, pepsin)))
        # Cleave sequences based on cleaving sites and remove peptides which are outside the defined allowed length
        chopped_peptides = list(remove_pep_len(cleave_protein(sequence, cleave_sites), min_len, max_len))

        yield from zip([a_DATA[0][num]] * len(chopped_peptides), chopped_peptides)


def cleave_protein(sequence, cleave_sites):
    # Initialize starting point
    start_res = 0
    for num, res in enumerate(sequence):
        if num in cleave_sites:
            # Extract sequence up to cleavage site
            yield sequence[start_res: num]
            # Set new starting point
            start_res = num


def remove_pep_len(sequence_list, min_len, max_len):
    # Yield only sequences which are inside allowed length
    for sequence in sequence_list:
        if len(sequence) >= min_len and len(sequence) <= max_len:
            yield sequence





