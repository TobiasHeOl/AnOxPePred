import AO_Utils as ap
import numpy as np
import argparse
import os
from datetime import datetime
from posixpath import join as urljoin

# Libraries used
# Python 3.6.8 (argparse, os, datetime)
# TensorFlow 1.12.0
# BioPython 1.72
# Numpy 1.15.4
# Pandas 0.23.4


# type          - either 'protein', 'proteolysis' or 'peptide'
# p_len_min     - 2-30 (never higher than p_len_max)
# p_len_max     - 2-30 (never lower than p_len_min)
# nr_top        - 1-20
# trypsin       - 0 or 1 needed only if type is proteolysis
# chytryp_H     - 0 or 1 needed only if type is proteolysis
# chytryp_L     - 0 or 1 needed only if type is proteolysis
# pepsin        - 0 or 1 needed only if type is proteolysis
# pred_nr       - This value should not be chosen by the user on the web server,
#                 as it relates to how much memory there is available

# params        - Always the same dir (not chosen by user)
# zscale        - Always the same file (not chosen by user)
# if_web        - Always true for web server
# web_out       - Url path when using web-server
# job_id        - Give the job an ID. If None a random one is generated for it


script_root = os.path.dirname(os.path.abspath(__file__))

parser = argparse.ArgumentParser(description='AnOxPe-Pred: Predictor of antioxidant properties of peptides.')
parser.add_argument(dest='in_file', default=os.path.join(script_root, 'AO_Examples\Protein_example.fsa'), help="FSA FILE: fasta file with peptides or proteins to test.")
parser.add_argument('-o', dest='out_path', default=os.path.join(script_root, 'AO_Results'), help="DIR PATH: path to output directory.")
parser.add_argument('--params', dest='params_dir', default=os.path.join(script_root, '01_CNN_params_H100_F100_B32_L0.0001'), help="DIR PATH: path to directory with parameters.")
parser.add_argument('--zscale', dest='zscale', default=os.path.join(script_root, 'Extended_Zscale.txt'), help="TXT FILE: path to zscale file.")
parser.add_argument('--type', dest='type', default='proteolysis', help='STR: protein, proteolysis or peptide.')
parser.add_argument('--p_len_min', dest='p_len_min', default=10, help='INT: minimum peptide length.')
parser.add_argument('--p_len_max', dest='p_len_max', default=20, help='INT: maximum peptide length.')
parser.add_argument('--nr_top', dest='nr_top', default=5, help='INT: number of best peptides from each cluster to show in "top" file.')
parser.add_argument('--pred_nr', dest='pred_nr', default=10000, help='INT: number of maximum predictions at the same time. Higher number equals faster computation, but increases needed computational power.')
parser.add_argument('--if_web', dest='if_web', default='True', help='STR: web output or not (True/False).')
parser.add_argument('--web_out', dest='web_out', default='http://services.bioinformatics.dtu.dk/services/AnOxPePred-1.0/tmp/', help='WEB_URL:  URL to files output.')
parser.add_argument('--job_id', dest='job_id', default='None', help='STR: ID given as name for directory. If None random ID is given.')
parser.add_argument('--trypsin', dest='protease_trypsin', default=1, help='INT: 1 if use protease, 0 if not.')
parser.add_argument('--chytryp_H', dest='protease_chytryp_H', default=0, help='INT: 1 if use protease, 0 if not.')
parser.add_argument('--chytryp_L', dest='protease_chytryp_L', default=0, help='INT: 1 if use protease, 0 if not.')
parser.add_argument('--pepsin', dest='protease_pepsin', default=0, help='INT: 1 if use protease, 0 if not.')
args = vars(parser.parse_args())


INPUT_FILE  = str(args['in_file'])
OUT_TIME    = ap.remove_element(datetime.now().isoformat(), ['-', ':', '.'])
OUT_PATH    = os.path.join(args['out_path'], str(os.getpid()) + str(OUT_TIME))
PARAM_dir   = args['params_dir']
zscale      = args['zscale']
TYPE        = args['type']
P_LEN_MIN   = args['p_len_min']
P_LEN_MAX   = args['p_len_max']
NR_TOP      = args['nr_top']
PRED_NR     = args['pred_nr']
IF_WEB      = args['if_web']
JOB_ID      = args['job_id']
WEB_OUT     = urljoin(args['web_out'], str(os.getpid()) + str(OUT_TIME))
TRYPSIN     = args['protease_trypsin']
CHYTRYP_H   = args['protease_chytryp_H']
CHYTRYP_L   = args['protease_chytryp_L']
PEPSIN      = args['protease_pepsin']

##########################################
# Validate inputs
##########################################

# Checks whether it is a corrupted fasta file
ap.check_fasta(INPUT_FILE)
# Checks if integers are integers and makes sure they are integers
integer_values = list(ap.check_if_int([P_LEN_MIN, P_LEN_MAX, NR_TOP, PRED_NR, TRYPSIN, CHYTRYP_H, CHYTRYP_L, PEPSIN]))
P_LEN_MIN, P_LEN_MAX, NR_TOP, PRED_NR, TRYPSIN, CHYTRYP_H, CHYTRYP_L, PEPSIN = integer_values
# Checks if peptide length is within allowed limit
ap.check_pep_len(P_LEN_MIN, P_LEN_MAX)
# Checks if NR_TOP is within allowed limit
ap.check_int_in_interval(NR_TOP, min_nr=1, max_nr=20, name='Number of top predicted')
# Checks if web_out is set when if_web is True
ap.web_out_true(WEB_OUT, IF_WEB)

##########################################
# Initialize output directory
if not JOB_ID == 'None':
    OUT_PATH = os.path.join(args['out_path'], JOB_ID)
    WEB_OUT = urljoin(args['web_out'], JOB_ID)

if os.path.exists(OUT_PATH) is False:
    os.makedirs(OUT_PATH)


NAMES = ['Scavenger', 'Chelator']

# Read file into array
a_DATA = np.reshape(np.stack(ap.convert_fsa_list(INPUT_FILE)), (-1, 2))
a_DATA = np.stack(zip(*a_DATA))

# Checks for characters within the sequences, which are not one of the standard 20 AA's
ap.check_characters(a_DATA)

##########################################


def print_web(Scav, Chel, TYPE):

    if TYPE == 'protein':

        print('# For publication of results, please cite:')
        print('# Coming soon...')
        print('# Only the top 3 peptides of the 20 highest scoring clusters will be shown in this interface')
        print('# For a full list see the following output files:')
        print('# <a href=', urljoin(WEB_OUT, NAMES[0] + '_All.txt'), '>', NAMES[0], '_All.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[1] + '_All.txt'), '>', NAMES[1], '_All.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[0] + '_Top.txt'), '>', NAMES[0], '_Top.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[1] + '_Top.txt'), '>', NAMES[1], '_Top.txt', '</a>', sep='')
        print('# Column 1: Predicted free radical scavenger (FRS) score or chelation (CHEL) score')
        print('# Column 2: Peptide sequence')
        print('# Column 3: Accession number peptide is present in')
        print('# FRS score')

        for clust in Scav[:20]:
            for seq in clust[:3]:
                print(round(seq[0][0], 8), "{:<31}".format(seq[1]), ' '.join(sorted(seq[2])), sep='\t')
            print('# ------------------------------------------')
        print('#')
        print('#')
        print('# CHEL score')
        for clust in Chel[:20]:
            for seq in clust[:3]:
                print(round(seq[0][1], 8), "{:<31}".format(seq[1]), ' '.join(sorted(seq[2])), sep='\t')
            print('# ------------------------------------------')

    elif TYPE == 'peptide':
        print('# For publication of results, please cite:')
        print('# Coming soon...')
        print('# Only the top 100 peptides will be shown in this interface')
        print('# For a full list see the following output files:')
        print('# <a href=', urljoin(WEB_OUT, NAMES[0] + '_All.txt'), '>', NAMES[0], '_All.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[1] + '_All.txt'), '>', NAMES[1], '_All.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[0] + '_Top.txt'), '>', NAMES[0], '_Top.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[1] + '_Top.txt'), '>', NAMES[1], '_Top.txt', '</a>', sep='')
        print('# Column 1: Predicted free radical scavenger (FRS) score or chelation (CHEL) score')
        print('# Column 2: Peptide sequence')
        print('# Column 3: Peptide name')
        print('# FRS score')

        for seq in Scav[:20]:
            print(round(seq[0][0], 8), "{:<31}".format(seq[1]), ' '.join(sorted(seq[2])), sep='\t')
        print('#')
        print('#')
        print('# CHEL score')
        for seq in Chel[:20]:
            print(round(seq[0][1], 8), "{:<31}".format(seq[1]), ' '.join(sorted(seq[2])), sep='\t')

    elif TYPE == 'proteolysis':

        print('# For publication of results, please cite:')
        print('# Coming soon...')
        print('# Only the top 100 peptides will be shown in this interface')
        print('# For a full list see the following output files:')
        print('# <a href=', urljoin(WEB_OUT, NAMES[0] + '_All.txt'), '>', NAMES[0], '_All.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[1] + '_All.txt'), '>', NAMES[1], '_All.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[0] + '_Top.txt'), '>', NAMES[0], '_Top.txt', '</a>', sep='')
        print('# <a href=', urljoin(WEB_OUT, NAMES[1] + '_Top.txt'), '>', NAMES[1], '_Top.txt', '</a>', sep='')
        print('# Column 1: Predicted free radical scavenger (FRS) score or chelation (CHEL) score')
        print('# Column 2: Peptide sequence')
        print('# Column 3: Accession number/name peptide is present in')
        print('# FRS score')

        for seq in Scav[:20]:
            print(round(seq[0][0], 8), "{:<31}".format(seq[1]), ' '.join(sorted(seq[2])), sep='\t')
        print('#')
        print('#')
        print('# CHEL score')
        for seq in Chel[:20]:
            print(round(seq[0][1], 8), "{:<31}".format(seq[1]), ' '.join(sorted(seq[2])), sep='\t')


if TYPE == 'peptide':

    # Check if peptides are of allowed length (2-31)
    ap.check_length(a_DATA)
    # Re-define to make it compatible for OUTPATH
    a_DATA = [[[i] for i in a_DATA[0]], a_DATA[1]]

    # Predict AO of each peptide
    Y_PRED = ap.peptide_predict(zscale, a_DATA, PARAM_dir, PRED_NR)

    # Sorts lists
    Scav = sorted(Y_PRED, key=lambda x: x[0][0], reverse=True)
    Chel = sorted(Y_PRED, key=lambda x: x[0][1], reverse=True)

    # pd.DataFrame(data=Y_PRED).to_csv(OUT_PATH+'_csv.csv')
    ap.pep_save_topAO(Scav, Chel, NR_TOP, OUT_PATH, NAMES)
    ap.pep_save_allAO(Scav, Chel, OUT_PATH, NAMES)

elif TYPE == 'protein':

    # Define length of peptides from input values
    cut_range = range(int(P_LEN_MIN), int(P_LEN_MAX) + 1)
    # Chops proteins into peptides of defined length
    Y_chopped = list(ap.outer_protein_chop(a_DATA, cut_range))

    # Predicts AO of each peptide
    Y_PRED = ap.peptide_predict(zscale, Y_chopped, PARAM_dir, PRED_NR)

    # Clusters peptides. This is done for an easier overview
    ident_peps = list(ap.homology_partition(Y_PRED, ident=0.7, key=1))

    # Sorts nested lists
    Scav = [sorted(i, key=lambda x: x[0][0], reverse=True) for i in ident_peps]
    Scav = sorted(Scav, key=lambda x: x[0][0][0], reverse=True)
    Chel = [sorted(j, key=lambda x: x[0][1], reverse=True) for j in ident_peps]
    Chel = sorted(Chel, key=lambda x: x[0][0][1], reverse=True)

    # Save the output
    ap.prot_clust_topAO(Scav, Chel, NR_TOP, OUT_PATH, NAMES)
    ap.prot_save_allAO(Scav, Chel, OUT_PATH, NAMES)

elif TYPE == 'proteolysis':

    # Check if protease has been chosen
    ap.check_if_proteases([TRYPSIN, CHYTRYP_H, CHYTRYP_L, PEPSIN])
    # Cleave proteins based on proteolysis enzymes selected
    cleaved_protein = ap.outer_protein_cleave(a_DATA, P_LEN_MIN, P_LEN_MAX, TRYPSIN, CHYTRYP_H, CHYTRYP_L, PEPSIN)

    # Groups identical sequences
    grouped_peptides = ap.switch_dictionary(cleaved_protein)

    # Redefine data after being cleaved and grouped
    a_DATA = [grouped_peptides[0], grouped_peptides[1].tolist()]

    # Predict AO of each peptide
    Y_PRED = ap.peptide_predict(zscale, a_DATA, PARAM_dir, PRED_NR)

    # Sorts lists
    Scav = sorted(Y_PRED, key=lambda x: x[0][0], reverse=True)
    Chel = sorted(Y_PRED, key=lambda x: x[0][1], reverse=True)

    # pd.DataFrame(data=Y_PRED).to_csv(OUT_PATH+'_csv.csv')
    ap.pep_save_topAO(Scav, Chel, NR_TOP, OUT_PATH, NAMES)
    ap.pep_save_allAO(Scav, Chel, OUT_PATH, NAMES)

else:
    print('Type does not exits. Use "peptide" or "protein"')
    exit()


if IF_WEB == 'True':
    print_web(Scav, Chel, TYPE)

